// Applications: each app uses one or more host APIs (ApplicationApi links). Port of apiapps.html.
import { useEffect, useRef, useState } from "react";
import { Alert, Badge, Button, Form, Modal } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import CFG from "../config.js";
import api, { removeAppLinks } from "../lib/api.js";
import { appRollup, byName, hostException } from "../lib/util.js";
import { sets as e9Sets } from "../lib/e9.js";
import { CrudPage } from "../components/Table.jsx";
import { useToast } from "../components/Toasts.jsx";
import { Empty, PageHeader, Spinner } from "../components/ui.jsx";

const hostLabel = h => h.apiHostName || h.apiHostUrl || "#" + h.id;

export default function Apps() {
  const navigate = useNavigate();
  const toast = useToast();
  const page = useRef();
  const look = useRef({ hosts: [], endpoints: [], links: [], hostExc: [], rollup: new Map() });
  const [setupError, setSetupError] = useState(undefined);   // undefined = checking
  const [linkApp, setLinkApp] = useState(null);

  useEffect(() => {
    api.list("apps").then(() => setSetupError(null)).catch(e => setSetupError(e.status === 404 ? e : null));
  }, []);

  async function loadLookups() {
    const [h, e, l, x] = await Promise.all([api.list("apihosts"), api.list("apiaudit"), api.list("apphosts"), api.list("hostexceptions").catch(() => [])]);
    look.current = { ...look.current, hosts: h, endpoints: e, links: l, hostExc: x };
  }
  const rollupOf = id => look.current.rollup.get(id);

  const render = {
    hostApis: (v, r) => {
      const x = rollupOf(r.id);
      if (!x || !x.hosts.length) return <span className="text-muted small">No hosts linked</span>;
      return x.hosts.map(h => {
        const exc = hostException(look.current.hostExc, h.id);
        return <span key={h.id} className={`badge ${exc ? "text-bg-warning" : "text-bg-light border"} me-1 mb-1 fw-normal`} title={`${h.apiHostUrl || ""}${exc ? " · excepted from auditing" : ""}`}>{hostLabel(h)}</span>;
      });
    },
    endpointTotal: (v, r) => {
      const x = rollupOf(r.id);
      if (!x) return "0";
      return <><b>{x.total}</b>{x.total !== x.active && <span className="small text-muted"> ({x.active} active)</span>}</>;
    }
  };

  if (setupError === undefined) return <><PageHeader title="Applications" /><Spinner /></>;
  return (
    <>
      <PageHeader title="Applications">An application uses one or more of your host APIs. <b>Link hosts</b> chooses which hosts it uses; a host can belong to more than one application. <b>Endpoints</b> is the total across all of an application's hosts. <b>Enterprise(9)</b> shows the application's logs.</PageHeader>
      {setupError ? (
        <Alert variant="warning"><strong>The API didn't answer on the Application routes.</strong> CockyAuditor expects <code>{CFG.endpoints.apps}</code> and <code>{CFG.endpoints.apphosts}</code> (set in <code>config.js</code>). Check the API has been deployed with <code>MapApplicationEndpoints()</code> and <code>MapApplicationApiEndpoints()</code>.
          <div className="small mt-2 text-muted">{setupError.message}</div></Alert>
      ) : (
        <CrudPage ref={page} resource="apps" render={render}
          beforeLoad={loadLookups}
          sort={rows => {
            look.current.rollup = new Map(appRollup(rows, look.current.links, look.current.hosts, look.current.endpoints).map(x => [x.app.id, x]));
            return rows.slice().sort(byName);
          }}
          // Remove the application's ApplicationApi links first, so the delete works whether or not the database cascades
          beforeDelete={app => removeAppLinks(l => l.applicationId === app.id)}
          rowActions={[
            { label: "Link hosts", onClick: setLinkApp },
            { label: "Endpoints", onClick: a => navigate("/endpoints?app=" + a.id) },
            {
              // Enterprise(9) logs for the app's linked API set; the badge is how many log categories its endpoints include
              variant: "warning",
              label: a => { const n = e9Sets(rollupOf(a.id)?.endpoints).length; return <>Enterprise(9){n > 0 && <Badge bg="dark" className="ms-1">{n}</Badge>}</>; },
              title: a => { const x = rollupOf(a.id), n = e9Sets(x?.endpoints).length;
                return !x?.hosts.length ? "No hosts linked yet; shows the standard log routes once hosts are linked"
                  : `${n} Enterprise(9) log set(s) registered on ${x.hosts.length} linked host(s)`; },
              onClick: a => navigate("/enterprise9?app=" + a.id)
            }
          ]}
          // After adding an app, go straight to choosing its hosts
          onCreated={saved => {
            const rows = page.current.rows();
            const app = saved.id ? rows.find(r => r.id === saved.id) : rows.filter(r => r.applicationName === saved.applicationName).sort((a, b) => b.id - a.id)[0];
            if (app) setLinkApp(app);
          }} />
      )}
      {linkApp && <LinkHosts app={linkApp} look={look.current} onClose={changed => { setLinkApp(null); if (changed) page.current?.reload(); }} toast={toast} />}
    </>
  );
}

// Choose which hosts an application uses
function LinkHosts({ app, look, onClose, toast }) {
  const { hosts, endpoints, links, hostExc } = look;
  const current = links.filter(l => l.applicationId === app.id);
  const [picked, setPicked] = useState(() => new Set(current.map(l => l.apiHostId)));
  const [q, setQ] = useState("");
  const [err, setErr] = useState("");
  const [saving, setSaving] = useState(false);
  const [show, setShow] = useState(true);
  const result = useRef(false);
  const close = changed => { result.current = changed; setShow(false); };

  const epCount = id => endpoints.filter(e => e.apiHostId === id).length;
  const sorted = hosts.slice().sort((a, b) => hostLabel(a).localeCompare(hostLabel(b)));
  const shown = sorted.filter(h => !q.trim() || [h.apiHostName, h.apiHostUrl, h.environment, h.id].some(v => String(v ?? "").toLowerCase().includes(q.trim().toLowerCase())));
  const total = [...picked].reduce((s, id) => s + epCount(id), 0);

  async function save() {
    const before = new Set(current.map(l => l.apiHostId));
    const toAdd = [...picked].filter(id => !before.has(id));
    const toRemove = current.filter(l => !picked.has(l.apiHostId));
    if (!toAdd.length && !toRemove.length) { close(false); return; }
    setSaving(true);
    const failures = [];
    await Promise.all([
      ...toAdd.map(id => api.create("apphosts", { applicationId: app.id, apiHostId: id, createdDate: new Date().toISOString() }).catch(e => failures.push(e.message))),
      ...toRemove.map(l => api.remove("apphosts", l.id).catch(e => failures.push(e.message)))
    ]);
    setSaving(false);
    if (failures.length) { setErr(`${failures.length} change(s) failed: ${failures[0]}`); result.current = true; return; }
    toast(`${app.applicationName || "App"}: ${toAdd.length ? `${toAdd.length} host(s) linked` : ""}${toAdd.length && toRemove.length ? ", " : ""}${toRemove.length ? `${toRemove.length} unlinked` : ""}.`);
    close(true);
  }

  return (
    <Modal show={show} onHide={() => close(result.current)} onExited={() => onClose(result.current)} size="lg" scrollable>
      <Modal.Header closeButton><Modal.Title as="h5">Hosts used by {app.applicationName || "app #" + app.id}</Modal.Title></Modal.Header>
      <Modal.Body>
        <Form.Control size="sm" className="mb-2" placeholder="Search hosts…" value={q} onChange={e => setQ(e.target.value)} />
        {shown.length ? <div className="list-group">{shown.map(h => {
          const exc = hostException(hostExc, h.id);
          const others = links.filter(l => l.apiHostId === h.id && l.applicationId !== app.id).length;
          return (
            <label key={h.id} className="list-group-item d-flex gap-3 align-items-start">
              <input className="form-check-input mt-1" type="checkbox" checked={picked.has(h.id)}
                onChange={e => setPicked(s => { const n = new Set(s); e.target.checked ? n.add(h.id) : n.delete(h.id); return n; })} />
              <span className="flex-grow-1"><span className="fw-semibold">{hostLabel(h)}</span>
                {exc && <Badge bg="warning" text="dark" className="ms-1">Excepted</Badge>}
                {h.environment && <span className="badge text-bg-light border ms-1 fw-normal">{h.environment}</span>}
                <br /><span className="small text-muted">{h.apiHostUrl || ""}{others ? ` · also used by ${others} other app${others === 1 ? "" : "s"}` : ""}</span></span>
              <span className="text-nowrap small"><b>{epCount(h.id)}</b> endpoints</span>
            </label>);
        })}</div> : <Empty>{hosts.length ? "No hosts match your search." : "No hosts yet. Add one on the Hosts page first."}</Empty>}
        {err && <Alert variant="danger" className="small mt-3 mb-0">{err}</Alert>}
      </Modal.Body>
      <Modal.Footer className="justify-content-between">
        <div className="small text-muted">{picked.size} host{picked.size === 1 ? "" : "s"} selected · {total} endpoint{total === 1 ? "" : "s"} in total</div>
        <div><Button variant="secondary" className="me-2" onClick={() => close(result.current)}>Cancel</Button>
          <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Save"}</Button></div>
      </Modal.Footer>
    </Modal>
  );
}
