// Exceptions: endpoint exceptions (AuditExceptions) and whole-host exceptions (ApiHostException). Port of apiexceptions.html.
import { useEffect, useRef, useState } from "react";
import { Alert, Form, Nav } from "react-bootstrap";
import { useSearchParams } from "react-router-dom";
import api from "../lib/api.js";
import { useDialogs } from "../components/Dialogs.jsx";
import { CrudPage } from "../components/Table.jsx";
import { ExpiryCell, PageHeader } from "../components/ui.jsx";

const render = { expirationDate: v => <ExpiryCell v={v} /> };

export default function Exceptions() {
  const [params, setParams] = useSearchParams();
  const dialogs = useDialogs();
  const hostPage = useRef();
  const tab = params.get("tab") === "hosts" || params.get("host") ? "hosts" : "endpoints";
  const [view, setView] = useState(params.get("audit") ? "audit" : "all");
  const [endpointId, setEndpointId] = useState(params.get("audit") || "");
  const [endpoints, setEndpoints] = useState(null);

  useEffect(() => {
    api.list("apiaudit").then(eps => { setEndpoints(eps); setEndpointId(id => id || (eps[0] ? String(eps[0].id) : "")); }).catch(() => setEndpoints([]));
  }, []);

  // Opened from Hosts → "Except host": start a new host exception for that host
  useEffect(() => {
    const hostId = params.get("host");
    if (!hostId) return;
    setParams({ tab: "hosts" }, { replace: true });
    api.list("hostexceptions").catch(() => []).then(rows =>
      dialogs.recordForm("hostexceptions", null, rows, { apiHostId: +hostId, active: true, approvalDate: new Date().toISOString() })
    ).then(saved => { if (saved) hostPage.current?.reload(); });
  }, []);   // eslint-disable-line react-hooks/exhaustive-deps

  const source = () => view === "active" ? "/active" : view === "audit" && endpointId ? "/audit/" + encodeURIComponent(endpointId) : "";

  return (
    <>
      <PageHeader title="Exceptions">Approved exclusions from auditing. <b>Endpoint exceptions</b> cover one endpoint, an API root URL or a path pattern like <code>/api/Student/*</code>. <b>Host exceptions</b> take a whole host out of auditing. Both apply only while active and not expired.</PageHeader>
      <Nav variant="tabs" className="mb-3" activeKey={tab} onSelect={k => setParams(k === "hosts" ? { tab: "hosts" } : {}, { replace: true })}>
        <Nav.Item><Nav.Link eventKey="endpoints">Endpoint exceptions</Nav.Link></Nav.Item>
        <Nav.Item><Nav.Link eventKey="hosts">Host exceptions</Nav.Link></Nav.Item>
      </Nav>
      {tab === "endpoints" ? (
        <CrudPage resource="auditexceptions" render={render} source={source} reloadKey={view + "|" + endpointId}
          toolbarExtra={<>
            <Form.Select size="sm" style={{ maxWidth: 170 }} value={view} onChange={e => setView(e.target.value)}>
              <option value="all">All exceptions</option><option value="active">Active only</option><option value="audit">For endpoint…</option>
            </Form.Select>
            {view === "audit" && <Form.Select size="sm" style={{ maxWidth: 260 }} value={endpointId} onChange={e => setEndpointId(e.target.value)}>
              {!endpoints ? <option value="">Loading endpoints…</option> : !endpoints.length ? <option value="">No endpoints yet</option>
                : endpoints.map(e => <option key={e.id} value={e.id}>#{e.id} {e.description || e.url || ""}</option>)}
            </Form.Select>}
          </>} />
      ) : (
        <>
          <Alert variant="info" className="small py-2">A host exception takes a whole API out of auditing: while it's active and not expired, the host can't be audited (Audit host is blocked and its endpoints are locked out of every run).</Alert>
          <CrudPage ref={hostPage} resource="hostexceptions" render={render} />
        </>
      )}
    </>
  );
}
