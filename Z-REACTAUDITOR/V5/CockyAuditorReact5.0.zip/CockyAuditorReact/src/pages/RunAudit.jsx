// Run Audit: check endpoints from this browser, walk a host's Swagger, save the run to History (port of apiaudit.html)
import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Alert, Badge, Button, Form } from "react-bootstrap";
import { Link, useSearchParams } from "react-router-dom";
import api from "../lib/api.js";
import { auditOne, expiredException, liveException, methodOf, scopeText, targetUrl } from "../lib/audit.js";
import { dupeNote, walkHost } from "../lib/swagger.js";
import { hostException, parseDate, val } from "../lib/util.js";
import { buildAuditResultPayload, summarizeAudit } from "../schema.js";
import { useDialogs } from "../components/Dialogs.jsx";
import { useToast } from "../components/Toasts.jsx";
import { Empty, ErrorBox, MethodBadge, PageHeader, Spinner, VerdictBadge } from "../components/ui.jsx";

const ICON = { pass: "✔", warn: "⚠", fail: "✖", info: "ℹ" };

export default function RunAudit() {
  const [params, setParams] = useSearchParams();
  const preselect = params.get("id");
  const dialogs = useDialogs(), toast = useToast();

  const [data, setData] = useState(null);          // { endpoints, hosts, exceptions, hostExceptions }
  const [loadError, setLoadError] = useState(null);
  const [hostFilter, setHostFilter] = useState(params.get("host") || "");
  const [search, setSearch] = useState("");
  const [picked, setPicked] = useState({});        // id -> bool (overrides the default pick)
  const [urls, setUrls] = useState({});            // id -> typed target URL
  const [checks, setChecks] = useState({});        // id -> check result ({ running: true } while running)
  const [running, setRunning] = useState(null);    // "3/10" while running
  const [walkMsg, setWalkMsg] = useState(null);
  const [walking, setWalking] = useState(false);
  const [save, setSave] = useState({ show: false, name: "", id: "", notes: "", touch: true, state: "idle", msg: null });
  const walkedOnce = useRef(false);

  // ---- load ----
  const load = useCallback(async () => {
    setLoadError(null);
    // Hosts and exceptions are optional here: if they fail, endpoints still work (and no exceptions are applied)
    const opt = (r, what) => api.list(r).catch(e => { toast(`Couldn't load ${what}: ${e.message}`, "warning"); return []; });
    try {
      const [endpoints, hosts, exceptions, hostExceptions] = await Promise.all([
        api.list("apiaudit"), opt("apihosts", "hosts"), opt("auditexceptions", "exceptions, so none are applied"), opt("hostexceptions", "host exceptions, so none are applied")
      ]);
      setData({ endpoints, hosts, exceptions, hostExceptions });
      return { endpoints, hosts, exceptions, hostExceptions };
    } catch (e) { setLoadError(e); return null; }
  }, [toast]);

  // ---- helpers bound to the current data ----
  const h = data || { endpoints: [], hosts: [], exceptions: [], hostExceptions: [] };
  const urlOf = (e, u = urls, d = h) => u[e.id] ?? targetUrl(e, d.hosts);
  const hostExcFor = (e, d = h) => hostException(d.hostExceptions, e.apiHostId);
  const liveExc = (e, d = h, u = urls) => liveException(d.exceptions, e, urlOf(e, u, d));
  const expiredExc = e => expiredException(h.exceptions, e, urlOf(e));
  const isPicked = (e, p = picked, d = h) => hostExcFor(e, d) ? false : e.id in p ? p[e.id]
    : (preselect ? String(e.id) === preselect : e.isActive !== false && !liveExc(e, d));
  const hostName = e => { const x = h.hosts.find(y => y.id === e.apiHostId); return x ? "Host: " + val(x.apiHostName) : ""; };

  const visibleOf = (d, hf, q) => d.endpoints.filter(e => (!hf || String(e.apiHostId) === hf) &&
    (!q || `${methodOf(e)} ${e.url} ${e.description} ${e.family}`.toLowerCase().includes(q)));
  const visible = useMemo(() => visibleOf(h, hostFilter, search.trim().toLowerCase()), [h, hostFilter, search]);   // eslint-disable-line react-hooks/exhaustive-deps

  // ---- running checks (6 at a time; results are flushed to the screen once per frame) ----
  const pending = useRef({}), frame = useRef(0);
  const flush = () => { frame.current = 0; const p = pending.current; pending.current = {}; setChecks(c => ({ ...c, ...p })); };
  async function runJobs(jobs, d) {
    if (!jobs.length) { toast("Select at least one endpoint.", "warning"); return; }
    setSave(s => ({ ...s, show: false, state: "idle", msg: null }));
    const start = Object.fromEntries(jobs.map(j => [j.e.id, { running: true }]));
    setChecks(start);
    setUrls(u => ({ ...u, ...Object.fromEntries(jobs.map(j => [j.e.id, j.url])) }));
    let next = 0, finished = 0;
    setRunning(`0/${jobs.length}`);
    const results = {};
    const worker = async () => {
      while (next < jobs.length) {
        const j = jobs[next++];
        const c = await auditOne(j.e, j.url, { hosts: d.hosts, exceptions: d.exceptions });
        results[j.e.id] = c; pending.current[j.e.id] = c;
        finished++; setRunning(`${finished}/${jobs.length}`);
        if (!frame.current) frame.current = requestAnimationFrame(flush);
      }
    };
    await Promise.all(Array.from({ length: Math.min(6, jobs.length) }, worker));
    if (frame.current) cancelAnimationFrame(frame.current);
    flush(); setRunning(null);
    showSaveCard(Object.entries(results).map(([id, check]) => ({ endpoint: d.endpoints.find(e => e.id === +id), check })));
  }
  const run = () => runJobs(visible.filter(e => isPicked(e) && !hostExcFor(e)).map(e => ({ e, url: urlOf(e).trim() })), h);

  // ---- save card ----
  function showSaveCard(pairs) {
    if (!pairs.length) return;
    let remembered = {};
    try { remembered = JSON.parse(localStorage.getItem("cocky.auditor") || "{}"); } catch { /* ignore */ }
    const src = pairs[0].endpoint;
    setSave(s => ({ ...s, show: true, state: "idle", msg: null,
      name: s.name || remembered.name || val(src.auditorName), id: s.id || (remembered.id ?? (src.auditorId || "")) }));
  }
  const auditedPairs = () => Object.entries(checks).filter(([, c]) => !c.running)
    .map(([id, check]) => ({ endpoint: h.endpoints.find(e => e.id === +id), check })).filter(p => p.endpoint);

  async function saveRun() {
    const pairs = auditedPairs();
    const auditorName = String(save.name || "").trim(), rawId = String(save.id ?? "");
    try { localStorage.setItem("cocky.auditor", JSON.stringify({ name: auditorName, id: rawId === "" ? null : +rawId })); } catch { /* ignore */ }
    const payload = buildAuditResultPayload(pairs, h.hosts, { auditorName, auditorId: rawId === "" ? 0 : +rawId, notes: save.notes.trim() });
    setSave(s => ({ ...s, state: "saving", msg: null }));
    let saved;
    try { saved = await api.create("apiauditresults", payload); }
    catch (err) { setSave(s => ({ ...s, state: "idle", msg: <Alert variant="danger" className="small mb-0">Saving the audit failed: {err.message}</Alert> })); return; }
    const resultId = saved && typeof saved === "object" ? saved.id : null;
    const problems = [];
    if (save.touch) {
      const now = new Date().toISOString();
      for (const { endpoint: e, check: c } of pairs) {
        const upd = { ...e, lastAuditDate: now, modifiedDate: now, endpointSecure: c.secure };
        if (resultId != null) upd.auditResultId = resultId;
        try { await api.update("apiaudit", e.id, upd); Object.assign(e, upd); } catch (err) { problems.push(`Endpoint #${e.id}: ${err.message}`); }
      }
      for (const hid of [...new Set(pairs.map(x => x.endpoint.apiHostId).filter(id => id != null))]) {
        const host = h.hosts.find(x => x.id === hid); if (!host) continue;
        const upd = { ...host, lastAuditDate: now };
        if (resultId != null) upd.lastAuditId = resultId;
        try { await api.update("apihosts", host.id, upd); Object.assign(host, upd); } catch (err) { problems.push(`Host #${host.id}: ${err.message}`); }
      }
    }
    setSave(s => ({ ...s, state: "saved", msg: (
      <Alert variant={problems.length ? "warning" : "success"} className="small mb-0">
        Audit{resultId != null ? " #" + resultId : ""} saved. <Link to="/history">View in History</Link>
        {problems.length > 0 && <><div className="mt-1">Some records couldn't be stamped:</div><ul className="mb-0">{problems.map((p, i) => <li key={i}>{p}</li>)}</ul></>}
      </Alert>) }));
  }

  // ---- one click: read the host's swagger.json, register new operations (after confirming), audit every endpoint ----
  async function walkAndAudit(hostId, d = h) {
    const host = d.hosts.find(x => x.id === hostId);
    if (!host) { setWalkMsg(<Alert variant="danger" className="small">Host #{hostId} not found.</Alert>); return; }
    setHostFilter(String(host.id));
    const hx = hostException(d.hostExceptions, host.id);
    if (hx) {
      setWalkMsg(<Alert variant="warning" className="small">{val(host.apiHostName) || host.apiHostUrl} is excepted from auditing
        (host exception #{hx.id}{hx.reason ? ": " + hx.reason : ""}{hx.approvedBy ? ", approved by " + hx.approvedBy : ""}{hx.expirationDate ? ", until " + parseDate(hx.expirationDate).toLocaleString() : ""}).{" "}
        <Link to="/exceptions?tab=hosts">Manage host exceptions</Link></Alert>);
      return;
    }
    if (!val(host.apiHostUrl)) { setWalkMsg(<Alert variant="danger" className="small">Host #{host.id} has no API Host Url, so there's no swagger.json to read. Edit it on the Hosts page.</Alert>); return; }
    setWalking(true);
    const say = t => setWalkMsg(<Alert variant="info" className="small py-2"><Spinner text={t} className="py-0" /></Alert>);
    say(`Reading swagger.json for ${val(host.apiHostName) || host.apiHostUrl}…`);
    let w;
    try {
      w = await walkHost(host, d.endpoints, { log: say, askCredentials: dialogs.credentials, confirmChanges: dialogs.confirmChanges });
    } catch (e) {
      setWalking(false);
      setWalkMsg(e.kind === "cancel" ? null : <Alert variant="danger" className="small">Couldn't read Swagger for this host: {e.message}
        <div className="mt-1">You can still audit the endpoints already registered: they're listed below.</div></Alert>);
      return;
    }
    const nd = { ...d, endpoints: w.endpoints };
    setData(nd);
    // Tick every active endpoint on this host that isn't covered by an exception
    const np = {};
    nd.endpoints.forEach(e => { if (e.apiHostId === host.id) np[e.id] = e.isActive !== false && !liveExc(e, nd, {}); });
    setPicked(np); setUrls({}); setSearch("");
    setWalkMsg(
      <Alert variant={w.failures.length ? "warning" : "success"} className="small py-2">
        <b>{w.parsed.title || "API"}</b> {w.parsed.version}: {w.parsed.endpoints.length} operations in Swagger.{" "}
        <b>{w.matched}</b> already registered, so they were not added again.{" "}
        {w.created.length ? <><b>{w.created.length}</b> new endpoint(s) registered{w.hostDefaultCount ? `, with ${w.hostDefaultCount} default field(s) from the host` : ""}{w.template ? ` (other details copied from #${w.template.id})` : ""}.</> : "No new endpoints."}
        {w.linked > 0 && <><br />{w.linked} existing endpoint(s) weren't linked to this host; they are now (instead of being added again).</>}
        {w.dupes?.length > 0 && <><br />{dupeNote(w.dupes)}</>}
        {w.refreshed > 0 && <><br />{w.refreshed} existing endpoint(s) updated with the host's details.</>}
        {w.notInSwagger.length > 0 && <><br />{w.notInSwagger.length} registered endpoint(s) are no longer in Swagger: {w.notInSwagger.slice(0, 6).map(e => e.description || e.url).join(", ")}{w.notInSwagger.length > 6 ? "…" : ""}. They're still audited; use <b>Sync Swagger</b> on the Hosts page to mark them inactive.</>}
        {w.failures.length > 0 && <><br />{w.failures.length} couldn't be registered: {w.failures.slice(0, 3).join("; ")}</>}
        {w.filled.length > 0 && <><br />Required fields filled with "N/A"/0: {w.filled.join(", ")}.</>}
      </Alert>);
    const jobs = visibleOf(nd, String(host.id), "").filter(e => isPicked(e, np, nd) && !hostExcFor(e, nd)).map(e => ({ e, url: targetUrl(e, nd.hosts) }));
    await runJobs(jobs, nd);
    setWalking(false);
  }

  useEffect(() => { load(); }, []);   // eslint-disable-line react-hooks/exhaustive-deps

  // /audit?host=7&walk=1 (Hosts → Audit host): walk once per request, and drop "walk" so a refresh doesn't walk again.
  // Watches the address, so it also works when Audit host is opened while this page is already showing.
  const walkReq = params.has("walk") ? params.get("host") : null;
  useEffect(() => {
    if (!walkReq) { walkedOnce.current = false; return; }   // request handled (or none): ready for the next one
    if (!data || walkedOnce.current) return;
    walkedOnce.current = true;
    setParams({ host: walkReq }, { replace: true });
    setChecks({}); setPicked({}); setUrls({});
    walkAndAudit(+walkReq, data);
  }, [walkReq, data]);   // eslint-disable-line react-hooks/exhaustive-deps

  // ---- render ----
  const hx = hostFilter && hostException(h.hostExceptions, +hostFilter);
  const done = Object.values(checks).filter(c => !c.running);
  const count = v => done.filter(c => c.verdict === v).length;
  const picks = visible.filter(e => !hostExcFor(e));
  const allChecked = picks.length > 0 && picks.every(e => isPicked(e));
  const exceptedHosts = [...new Set(visible.map(e => hostExcFor(e)).filter(Boolean))];
  const totals = save.show ? summarizeAudit(auditedPairs(), h.hosts) : null;

  return (
    <>
      <PageHeader title="Run Audit">Endpoints covered by an active exception are left unticked. Checks each selected endpoint from this browser: reachability, status code, response time, HTTPS and CORS, plus config consistency. Then save the run as one audit record in History.</PageHeader>
      <div className="card"><div className="card-body">
        <div className="d-flex flex-wrap gap-2 align-items-center mb-3">
          <Form.Select size="sm" id="hostFilter" style={{ maxWidth: 240 }} value={hostFilter} onChange={e => { setHostFilter(e.target.value); setParams(e.target.value ? { host: e.target.value } : {}, { replace: true }); }}>
            <option value="">All hosts</option>
            {h.hosts.map(x => <option key={x.id} value={x.id}>#{x.id} {val(x.apiHostName) || val(x.apiHostUrl)} ({h.endpoints.filter(e => e.apiHostId === x.id).length}){hostException(h.hostExceptions, x.id) ? " (excepted)" : ""}</option>)}
          </Form.Select>
          <Form.Control size="sm" id="search" style={{ maxWidth: 200 }} placeholder="Filter endpoints…" value={search} onChange={e => setSearch(e.target.value)} />
          <Button size="sm" variant="success" id="walk" disabled={!hostFilter || !!hx || walking || !!running}
            title={!hostFilter ? "Pick a host first" : hx ? "This host is excepted from auditing" : "Read this host's swagger.json, register any new operations, and audit every endpoint"}
            onClick={() => walkAndAudit(+hostFilter)}>Walk Swagger &amp; audit host</Button>
          <Button size="sm" id="run" disabled={!!running || walking} onClick={run}>{running ? `Running… ${running}` : "Run selected"}</Button>
          <span className="ms-auto small text-muted" id="summary">{done.length ? `${count("pass")} passed · ${count("warn")} warnings · ${count("fail")} failed` : ""}</span>
        </div>
        <div id="walkMsg">{walkMsg}</div>
        <div id="list">
          {loadError ? <ErrorBox error={loadError} onRetry={load} />
            : !data ? <Spinner text="Loading endpoints…" />
            : !h.endpoints.length ? <Empty>No endpoints to audit yet. <Link to="/hosts?add=1">Add an API from Swagger</Link> to import its endpoints.</Empty>
            : !visible.length ? <Empty>No endpoints match this host/filter.</Empty>
            : <>
              {exceptedHosts.length > 0 && <Alert variant="warning" className="small py-2">{exceptedHosts.length} host(s) excepted from auditing, so their endpoints are locked out of this run:{" "}
                {exceptedHosts.map((x, i) => { const hh = h.hosts.find(y => y.id === x.apiHostId); return <span key={x.id}>{i > 0 && "; "}<b>{val(hh?.apiHostName) || "#" + x.apiHostId}</b> (exception #{x.id}{x.reason ? ": " + x.reason : ""})</span>; })}</Alert>}
              <div className="table-responsive"><table className="table table-sm align-middle">
                <thead><tr>
                  <th style={{ width: 32 }}><Form.Check id="all" checked={allChecked} disabled={!picks.length}
                    onChange={e => setPicked(p => ({ ...p, ...Object.fromEntries(picks.map(x => [x.id, e.target.checked])) }))} /></th>
                  <th>Endpoint</th><th>Target URL</th><th>Result</th></tr></thead>
                <tbody>{visible.map(e => {
                  const c = checks[e.id], hxe = hostExcFor(e), le = liveExc(e), ee = !le && expiredExc(e);
                  return (
                    <Fragment key={e.id}>
                      <tr data-id={e.id}>
                        <td><Form.Check className="pick" checked={isPicked(e)} disabled={!!hxe} onChange={ev => setPicked(p => ({ ...p, [e.id]: ev.target.checked }))} /></td>
                        <td><div className="fw-semibold"><MethodBadge method={methodOf(e)} /> #{e.id} {val(e.url) || val(e.description) || "(no description)"}</div>
                          <div className="small text-muted">{[hostName(e), val(e.environment), val(e.endpointType)].filter(Boolean).join(" · ")}</div>
                          {hxe && <Badge bg="warning" text="dark" title={hxe.reason || ""}>Host excepted (#{hxe.id}), can't be audited</Badge>}
                          {le && <Badge bg="info" text="dark" title={le.reason || ""}>Excluded by exception #{le.id} · {scopeText(le)}</Badge>}
                          {ee && <Badge bg="danger">Exception #{ee.id} expired</Badge>}</td>
                        <td style={{ minWidth: 260 }}><Form.Control size="sm" className="target" placeholder="https://host/path" value={urlOf(e)} onChange={ev => setUrls(u => ({ ...u, [e.id]: ev.target.value }))} /></td>
                        <td className="text-nowrap verdict">{c ? <><VerdictBadge verdict={c.running ? "running" : c.verdict} />{c.ms != null && <span className="small text-muted"> {Math.round(c.ms)} ms</span>}</> : <span className="text-muted small">Not run</span>}</td>
                      </tr>
                      {c && !c.running && <tr className="detail"><td></td><td colSpan={3}><ul className="list-unstyled small mb-1 check-list">
                        {c.findings.map((x, i) => <li key={i} className={`lvl-${x.level}`}>{ICON[x.level]} {x.text}</li>)}</ul></td></tr>}
                    </Fragment>);
                })}</tbody>
              </table></div>
            </>}
        </div>
      </div></div>

      {save.show && <div className="card mt-3" id="saveCard"><div className="card-body">
        <h5 className="mb-3">Save this audit</h5>
        <div className="row g-3">
          <div className="col-md-5"><Form.Label className="small mb-1" htmlFor="auditorName">Auditor name</Form.Label>
            <Form.Control size="sm" id="auditorName" value={save.name} onChange={e => setSave(s => ({ ...s, name: e.target.value }))} /></div>
          <div className="col-md-2"><Form.Label className="small mb-1" htmlFor="auditorId">Auditor ID</Form.Label>
            <Form.Control size="sm" id="auditorId" type="number" value={save.id} onChange={e => setSave(s => ({ ...s, id: e.target.value }))} /></div>
          <div className="col-md-5 small">{totals && <><div className="text-muted mb-1">Will be saved as</div>
            Hosts: <b>{totals.totalApiHosts}</b> ({totals.apiHostsSecure} secure, {totals.apiHostsInsecure} insecure)<br />
            Endpoints: <b>{totals.totalApiEndpoints}</b> ({totals.totalEndpointsSecure} secure, {totals.totalEndpointsInsecure} insecure)</>}</div>
          <div className="col-12"><Form.Label className="small mb-1" htmlFor="notes">Notes</Form.Label>
            <Form.Control size="sm" id="notes" placeholder="e.g. Weekly audit" value={save.notes} onChange={e => setSave(s => ({ ...s, notes: e.target.value }))} />
            <div className="form-text">A per-endpoint summary (verdict, status, response time, warnings and failures) is added after your notes.</div></div>
          <div className="col-12 d-flex flex-wrap gap-3 align-items-center">
            <Button size="sm" variant="success" id="saveRun" disabled={save.state !== "idle"} onClick={saveRun}>
              {save.state === "saving" ? "Saving…" : save.state === "saved" ? "Saved" : "Save audit to History"}</Button>
            <Form.Check id="touch" className="small" checked={save.touch} onChange={e => setSave(s => ({ ...s, touch: e.target.checked }))}
              label="Also stamp the audited endpoints and hosts with this audit (Last Audit Date + result ID)" />
          </div>
          <div className="col-12" id="saveMsg">{save.msg}</div>
        </div>
      </div></div>}

      <div className="small text-muted mt-3">Browsers only let a page read a response when the target API allows this page's origin (CORS). When it doesn't, the audit can still tell whether the endpoint is up, but not its status code.</div>
    </>
  );
}
