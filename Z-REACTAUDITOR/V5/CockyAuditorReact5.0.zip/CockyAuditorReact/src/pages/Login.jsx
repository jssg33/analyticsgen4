// Sign-in page: hard-coded test user audit / audit (see lib/auth.js)
import { useState } from "react";
import { Button, Form } from "react-bootstrap";
import { Navigate, useNavigate, useSearchParams } from "react-router-dom";
import CFG from "../config.js";
import { safeNext, signIn } from "../lib/auth.js";
import { useAuth, useTitle } from "../components/Layout.jsx";

export default function Login() {
  useTitle("Sign in");
  const [params] = useSearchParams();
  const next = safeNext(params.get("next"));
  const navigate = useNavigate();
  const { signedIn } = useAuth();
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");

  if (signedIn) return <Navigate to={next} replace />;   // already signed in: skip the form

  const submit = e => {
    e.preventDefault();
    if (!login.trim() || !password) { setErr("Enter your username and password."); return; }
    if (signIn(login.trim(), password)) navigate(next, { replace: true });
    else { setErr("Username or password is incorrect."); setPassword(""); }
  };

  return (
    <div className="login-page login">
      <main className="login-card">
        <div className="eyebrow">REST API security auditing</div>
        <h1 className="brand-title">Cocky<span>Auditor</span></h1>
        <div className="sub">Sign in to continue.</div>
        <Form onSubmit={submit} noValidate autoComplete="off" id="loginForm">
          <div className="mb-3">
            <Form.Label htmlFor="login">Username</Form.Label>
            <Form.Control id="login" autoComplete="username" autoCapitalize="off" spellCheck={false} autoFocus
              value={login} onChange={e => { setLogin(e.target.value); setErr(""); }} />
          </div>
          <div className="mb-2">
            <Form.Label htmlFor="password">Password</Form.Label>
            <Form.Control id="password" type="password" autoComplete="current-password"
              value={password} onChange={e => { setPassword(e.target.value); setErr(""); }} />
          </div>
          <div className="err" id="err" role="alert">{err}</div>
          <Button className="btn-amber w-100 mt-2" type="submit">Sign in</Button>
        </Form>
        <div className="foot" id="foot">Build {CFG.version}<br />{CFG.copyright}</div>
      </main>
    </div>
  );
}
