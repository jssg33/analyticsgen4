// Hosts: each host is one API (port of apihosts.html)
import { useEffect, useRef, useState } from "react";
import { Badge, Button } from "react-bootstrap";
import { useNavigate, useSearchParams } from "react-router-dom";
import api, { removeAppLinks } from "../lib/api.js";
import { hostDefaults, pushHostDetails } from "../lib/swagger.js";
import { hostException, isLiveException, parseDate, titleCase } from "../lib/util.js";
import { useDialogs } from "../components/Dialogs.jsx";
import { CrudPage } from "../components/Table.jsx";
import { useToast } from "../components/Toasts.jsx";
import { FmtValue, PageHeader } from "../components/ui.jsx";

export default function Hosts() {
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const dialogs = useDialogs(), toast = useToast();
  const page = useRef();
  const [hostExceptions, setHostExceptions] = useState([]);

  // Whole-host exceptions: shown as a badge next to the host name, and they block "Audit host"
  useEffect(() => {
    api.list("hostexceptions").then(setHostExceptions).catch(e => toast("Couldn't load host exceptions: " + e.message, "warning"));
  }, [toast]);

  const addSwagger = async () => { if (await dialogs.swagger(null)) page.current?.reload(); };
  // Opened as /hosts?add=1 (Welcome → "+ Add an API")
  useEffect(() => {
    if (params.has("add")) { setParams({}, { replace: true }); addSwagger(); }
  }, []);   // eslint-disable-line react-hooks/exhaustive-deps

  // Copy this host's filled-in defaults (contacts, department, building, DBA, Azure...) onto all of its endpoints
  async function pushDetails(h) {
    const d = hostDefaults(h), keys = Object.keys(d);
    if (!keys.length) { toast("This host has no default details filled in yet. Use Details to add them first.", "warning"); return; }
    const ok = await dialogs.confirm({ title: "Push details to endpoints?", okText: "Copy to endpoints",
      body: <><p>Copy {keys.length} filled-in field(s) from host "{h.apiHostName}" onto every endpoint of this host?</p>
        <p className="small text-muted">{keys.map(titleCase).join(", ")}</p><p className="mb-0">Endpoint values for these fields will be overwritten.</p></> });
    if (!ok) return;
    toast("Updating endpoints…", "info");
    try {
      const r = await pushHostDetails(h);
      toast(`${r.updated} of ${r.total} endpoint(s) updated` + (r.failures.length ? `, ${r.failures.length} failed: ${r.failures[0]}` : "."), r.failures.length ? "warning" : "success");
    } catch (e) { toast(e.message, "danger"); }
  }

  const render = {
    apiHostName: (v, r) => {
      const x = hostException(hostExceptions, r.id);
      return <><FmtValue v={v} type="string" />{x && <> <Badge bg="warning" text="dark" title={x.reason || ""}>Excepted #{x.id}{x.expirationDate ? " until " + parseDate(x.expirationDate).toLocaleDateString() : ""}</Badge></>}</>;
    }
  };

  return (
    <>
      <PageHeader title="Hosts">Each host is one API. <b>Audit host</b> reads its swagger.json (using the saved Swagger login, or asking for it), registers any new operations using the host's default details, and audits every endpoint on that host. <b>Push details</b> copies the host's details onto its existing endpoints.</PageHeader>
      <CrudPage ref={page} resource="apihosts" render={render} reloadKey={hostExceptions.some(isLiveException) ? hostExceptions.length : 0}
        toolbarExtra={<Button size="sm" variant="success" id="addSwagger" onClick={addSwagger}>+ Add API from Swagger</Button>}
        // ApplicationApis has a foreign key to Apihosts (no cascade), so unlink the host from its applications first
        beforeDelete={h => removeAppLinks(l => l.apiHostId === h.id)}
        rowActions={[
          { label: "Audit host", onClick: h => {
              const x = hostException(hostExceptions, h.id);
              if (x) { toast(`"${h.apiHostName}" is excepted from auditing (host exception #${x.id}${x.reason ? ": " + x.reason : ""}). End or expire the exception to audit it.`, "warning"); return; }
              navigate(`/audit?host=${h.id}&walk=1`);
            } },
          { label: "Sync Swagger", onClick: async h => { if (await dialogs.swagger(h)) page.current?.reload(); } },
          { label: "Details", onClick: async h => {
              const saved = await dialogs.recordForm("apihosts", h, page.current.rows(), {}, { view: "details" });
              if (saved) { page.current.reload(); toast("Host details saved. They're copied to this host's endpoints on the next Audit host, or use Push details now."); }
            } },
          { label: "Push details", onClick: pushDetails },
          { label: "Except host", onClick: h => navigate("/exceptions?host=" + h.id) }
        ]} />
    </>
  );
}
