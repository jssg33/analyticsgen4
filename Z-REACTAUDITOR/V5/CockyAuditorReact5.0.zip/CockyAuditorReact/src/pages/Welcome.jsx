// Home page: live counts, quick links and build history (port of index.html)
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import CFG from "../config.js";
import api from "../lib/api.js";
import { signOut } from "../lib/auth.js";
import { dateMs, isLiveException } from "../lib/util.js";
import { useAuth, useTitle } from "../components/Layout.jsx";
import art from "./welcomeArt.js";

const QUICK = [
  { key: "apps", to: "/apps", label: "Apps" },
  { key: "apihosts", to: "/hosts", label: "Hosts" },
  { key: "apiaudit", to: "/endpoints", label: "Endpoints" },
  { key: "apiauditresults", to: "/history", label: "Audits" },
  { key: "auditexceptions", to: "/exceptions", label: "Endpoint exc." },
  { key: "hostexceptions", to: "/exceptions?tab=hosts", label: "Host exc." }
];

export default function Welcome() {
  useTitle("Welcome");
  const { username } = useAuth();
  const navigate = useNavigate();
  const [counts, setCounts] = useState({});   // key -> { n, sub, err }
  const [status, setStatus] = useState({ text: "Connecting to the API…" });

  useEffect(() => {
    let live = true;
    Promise.allSettled(QUICK.map(q => api.list(q.key))).then(results => {
      if (!live) return;
      let ok = 0, lastAudit = 0;
      const c = {};
      results.forEach((res, i) => {
        const key = QUICK[i].key;
        if (res.status === "fulfilled") {
          ok++;
          c[key] = { n: res.value.length };
          // Exceptions: count only live ones, note expired underneath
          if (/exceptions$/.test(key)) {
            const liveN = res.value.filter(isLiveException).length, expired = res.value.filter(x => x.active !== false).length - liveN;
            c[key] = { n: liveN, sub: expired ? `+${expired} expired` : "" };
          }
          if (key === "apiauditresults") res.value.forEach(a => { lastAudit = Math.max(lastAudit, dateMs(a.auditDate)); });
        } else if (key === "apps" && res.reason.status === 404) {
          ok++; c[key] = { n: "–", title: "The API didn't answer on the Application route" };   // Apps tables not deployed
        } else c[key] = { n: "!", err: res.reason.message };
      });
      setCounts(c);
      if (ok === 0) setStatus({ dot: "#e5484d", text: "Can't reach the API right now. Check that it's running and allows this page in CORS." });
      else setStatus({
        dot: ok === QUICK.length ? "#2fb36b" : "#f0a020",
        text: `API connected${ok < QUICK.length ? ` (${QUICK.length - ok} of ${QUICK.length} lists failed)` : ""}` +
          (lastAudit ? ` · Last audit ${new Date(lastAudit).toLocaleString()}` : " · No audits yet")
      });
    });
    return () => { live = false; };
  }, []);

  const host = (() => { try { return new URL(CFG.apiBaseUrl).host; } catch { return CFG.apiBaseUrl; } })();
  return (
    <div className="welcome">
      <section className="hero">
        <div className="wrap">
          <div>
            <div className="d-flex justify-content-between align-items-center gap-3">
              <div className="eyebrow">REST API security auditing</div>
              <div className="signed-in" id="signedIn">Signed in as <b>{username}</b>
                <a href="#/login" id="signOut" onClick={e => { e.preventDefault(); signOut(); setTimeout(() => navigate("/login", { replace: true })); }}>Sign out</a></div>
            </div>
            <h1 className="brand-title">Cocky<span>Auditor</span></h1>
            <div className="version"><b>Build {CFG.version}</b> {CFG.builds?.[0]?.title}</div>
            <p className="lead-text">Keep track of every host and endpoint you run, check them for reachability, HTTPS, response time and CORS, and keep a record of every audit and every approved exception.</p>
            <div className="cta d-flex flex-wrap gap-2 mt-4">
              <Link className="btn btn-amber" to="/audit">Run an audit</Link>
              <Link className="btn btn-ghost" to="/hosts?add=1">+ Add an API</Link>
              <Link className="btn btn-ghost" to="/dashboard">Open dashboard</Link>
              <Link className="btn btn-ghost" to="/enterprise9">Enterprise(9) logs</Link>
            </div>
            <div className="quick">
              {QUICK.map(q => {
                const c = counts[q.key];
                return (
                  <Link key={q.key} to={q.to}>
                    <div className="n" data-q={q.key} title={c?.err || c?.title} style={c?.err ? { color: "#e5484d" } : undefined}>{c ? c.n : "–"}</div>
                    <div className="l">{q.label}</div><div className="sub">{c?.sub || ""}</div>
                  </Link>);
              })}
            </div>
            <div className="status-line" id="status">{status.dot && <span style={{ color: status.dot }}>● </span>}{status.text}</div>
          </div>
          <div className="art" aria-hidden="true" dangerouslySetInnerHTML={{ __html: art }} />
        </div>
      </section>

      <section className="features">
        <div className="feature">
          <div className="ic"><svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><path d="M2 3h12v3H2zm0 4.5h12v3H2zM2 12h12v2H2z" /></svg></div>
          <h3>Inventory</h3>
          <p>Register hosts and every endpoint they serve, with owners, environments and security details.</p>
        </div>
        <div className="feature">
          <div className="ic"><svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><path d="M6.5 1a5.5 5.5 0 0 1 4.4 8.8l3.6 3.6-1.1 1.1-3.6-3.6A5.5 5.5 0 1 1 6.5 1zm0 1.5a4 4 0 1 0 0 8 4 4 0 0 0 0-8z" /></svg></div>
          <h3>Audit</h3>
          <p>Check reachability, status codes, HTTPS, response times and CORS, then save each run to History.</p>
        </div>
        <div className="feature">
          <div className="ic"><svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><path d="M8 1l6 2.5v4C14 11 11.4 14 8 15 4.6 14 2 11 2 7.5v-4z" /></svg></div>
          <h3>Exceptions</h3>
          <p>Record approved exclusions by endpoint, API root or path pattern, with who approved them and when they expire.</p>
        </div>
      </section>

      <section className="builds"><h2>Build history</h2>
        <ol id="builds">{(CFG.builds || []).map((b, i) => (
          <li key={b.build} className={i === 0 ? "current" : ""}>
            <div className="t">Build {b.build}: {b.title}{i === 0 && <> <span className="badge text-bg-warning">current</span></>}</div>
            {b.notes && <div className="n">{b.notes}</div>}
          </li>))}
        </ol>
      </section>

      <footer className="foot">CockyAuditor · connected to <span id="apiHost">{host}</span><br /><span id="copyright">{CFG.copyright}</span></footer>
    </div>
  );
}
