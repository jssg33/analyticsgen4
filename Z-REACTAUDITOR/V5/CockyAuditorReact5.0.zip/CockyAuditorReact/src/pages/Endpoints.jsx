// Endpoints: every endpoint registered for auditing, filterable by app or host (port of apiendpoints.html)
import { useEffect, useRef, useState } from "react";
import { Button, Form } from "react-bootstrap";
import { useNavigate, useSearchParams } from "react-router-dom";
import api from "../lib/api.js";
import { byName } from "../lib/util.js";
import { useDialogs } from "../components/Dialogs.jsx";
import { CrudPage } from "../components/Table.jsx";
import { PageHeader } from "../components/ui.jsx";

export default function Endpoints() {
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const dialogs = useDialogs();
  const page = useRef();
  // Filter value is "<hostId>" for one host or "app:<appId>" for every host linked to that app
  const filter = params.get("app") ? "app:" + params.get("app") : params.get("host") || "";
  const [opts, setOpts] = useState({ hosts: [], apps: [], links: [] });

  useEffect(() => {
    Promise.all([
      api.list("apihosts"),
      // Apps are optional: if the API doesn't have them yet, the filter just lists hosts
      Promise.all([api.list("apps"), api.list("apphosts")]).catch(() => [[], []])
    ]).then(([hosts, [apps, links]]) => setOpts({ hosts, apps: apps.slice().sort(byName), links })).catch(() => {});
  }, []);

  const setFilter = v => setParams(v.startsWith("app:") ? { app: v.slice(4) } : v ? { host: v } : {}, { replace: true });
  const sort = rows => {
    if (!filter) return rows;
    if (filter.startsWith("app:")) {
      const ids = new Set(opts.links.filter(l => String(l.applicationId) === filter.slice(4)).map(l => String(l.apiHostId)));
      return rows.filter(r => ids.has(String(r.apiHostId)));
    }
    return rows.filter(r => String(r.apiHostId) === filter);
  };

  return (
    <>
      <PageHeader title="Endpoints">Every endpoint registered for auditing. To import a whole API at once, use <b>Add API from Swagger</b>.</PageHeader>
      <CrudPage ref={page} resource="apiaudit" sort={sort} reloadKey={filter + "|" + opts.links.length}
        toolbarExtra={<>
          <Form.Select size="sm" className="host-filter" style={{ maxWidth: 240 }} value={filter} onChange={e => setFilter(e.target.value)}>
            <option value="">All apps &amp; hosts</option>
            {opts.apps.length > 0
              ? <><optgroup label="Apps">{opts.apps.map(a => <option key={a.id} value={"app:" + a.id}>{a.applicationName || "App #" + a.id}</option>)}</optgroup>
                  <optgroup label="Hosts">{opts.hosts.map(h => <option key={h.id} value={h.id}>#{h.id} {h.apiHostName || h.apiHostUrl || ""}</option>)}</optgroup></>
              : opts.hosts.map(h => <option key={h.id} value={h.id}>#{h.id} {h.apiHostName || h.apiHostUrl || ""}</option>)}
          </Form.Select>
          <Button size="sm" variant="success" onClick={async () => { if (await dialogs.swagger(null)) page.current?.reload(); }}>+ Add API from Swagger</Button>
        </>}
        rowActions={[
          { label: "Audit", onClick: r => navigate("/audit?id=" + r.id) },
          { label: "Exceptions", onClick: r => navigate("/exceptions?audit=" + r.id) }
        ]} />
    </>
  );
}
