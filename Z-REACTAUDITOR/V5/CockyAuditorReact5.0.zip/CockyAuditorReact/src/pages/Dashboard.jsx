// Dashboard: counts, apps roll-up, endpoints due for audit, recent results, active exceptions (port of apidashboard.html)
import { useEffect, useState } from "react";
import { Alert, Badge, ProgressBar } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import CFG from "../config.js";
import api from "../lib/api.js";
import { appRollup, dateMs, hostException, isLiveException, newestFirst, parseDate, unlinkedHosts } from "../lib/util.js";
import { DataTable } from "../components/Table.jsx";
import { Empty, PageHeader, Spinner } from "../components/ui.jsx";

const soon = x => x.expirationDate && parseDate(x.expirationDate) - Date.now() < 14 * 864e5;
const Until = ({ x }) => x.expirationDate
  ? <>{parseDate(x.expirationDate).toLocaleDateString()}{soon(x) && <><br /><Badge bg="warning" text="dark">expires soon</Badge></>}</>
  : <Badge bg="info" text="dark">No expiry</Badge>;

function Stat({ to, label, value, sub, error }) {
  return (
    <div className="col"><div className="card stat h-100"><div className="card-body"><Link to={to}>
      <div className="lbl">{label}</div>
      <div className="num" title={error?.message}>{error ? <span className="text-danger fs-6">Error</span> : value ?? "…"}</div>
      {sub && <div className="small text-muted">{sub}</div>}
    </Link></div></div></div>
  );
}

export default function Dashboard() {
  const navigate = useNavigate();
  const [d, setD] = useState(null);

  useEffect(() => {
    let live = true;
    const problems = [];
    const load = r => api.list(r).catch(e => { problems.push(e); return { error: e }; });
    Promise.all([
      load("apihosts"), load("apiaudit"), load("apiauditresults"), load("auditexceptions"), load("hostexceptions"),
      // Apps: a 404 means the Apps tables haven't been added to the API yet, which isn't an error worth a banner
      Promise.all([api.list("apps"), api.list("apphosts")]).then(([a, l]) => ({ apps: a, links: l }))
        .catch(e => e.status === 404 ? { missing: true } : (problems.push(e), { error: e }))
    ]).then(([hosts, endpoints, results, exceptions, hostExc, apps]) => { if (live) setD({ hosts, endpoints, results, exceptions, hostExc, apps, problems }); });
    return () => { live = false; };
  }, []);

  if (!d) return <><PageHeader title="Dashboard">Overview of everything CockyAuditor is tracking.</PageHeader><Spinner /></>;
  const ok = x => x && !x.error;
  const hosts = ok(d.hosts) ? d.hosts : [], endpoints = ok(d.endpoints) ? d.endpoints : null;
  const results = ok(d.results) ? d.results : null, exceptions = ok(d.exceptions) ? d.exceptions : null, hostExc = ok(d.hostExc) ? d.hostExc : null;

  // Exceptions: counts show only live ones (active and not expired); expired ones are noted underneath
  const summ = rows => rows ? { live: rows.filter(isLiveException), expired: rows.filter(x => x.active !== false && !isLiveException(x)).length } : null;
  const ep = summ(exceptions), hx = summ(hostExc);
  const excSub = s => s ? (s.expired ? <span className="text-danger">{s.expired} expired</span> : "active, not expired") : null;

  // Apps roll-up
  let roll = null, loose = [], looseEps = 0, linkedEps = 0;
  if (d.apps.apps) {
    roll = appRollup(d.apps.apps, d.apps.links, hosts, endpoints || []).sort((a, b) => b.total - a.total || String(a.app.applicationName || "").localeCompare(String(b.app.applicationName || "")));
    linkedEps = new Set(roll.flatMap(x => x.endpoints.map(e => e.id))).size;
    loose = unlinkedHosts(hosts, d.apps.links, d.apps.apps);
    looseEps = (endpoints || []).filter(e => loose.some(h => h.id === e.apiHostId)).length;
  }
  const max = roll ? roll.reduce((m, x) => Math.max(m, x.total), 0) : 0;
  const hostName = id => { const h = hosts.find(x => x.id === id); return h ? h.apiHostName || h.apiHostUrl : "#" + id; };
  const epName = id => { const e = (endpoints || []).find(x => x.id === id); return e ? e.description || e.url : "#" + id; };
  const week = Date.now() - 7 * 864e5;
  const due = endpoints ? endpoints.filter(e => e.isActive !== false && dateMs(e.lastAuditDate) < week).length : 0;

  return (
    <>
      <PageHeader title="Dashboard">Overview of everything CockyAuditor is tracking.</PageHeader>
      <div className="row row-cols-2 row-cols-md-3 row-cols-xl-6 g-3 mb-4" id="stats">
        <Stat to="/apps" label="Apps" value={d.apps.missing ? "–" : d.apps.apps?.length} error={d.apps.error}
          sub={d.apps.missing ? "not set up" : d.apps.apps ? `${linkedEps} endpoint${linkedEps === 1 ? "" : "s"} covered` : null} />
        <Stat to="/hosts" label="Hosts" value={ok(d.hosts) && d.hosts.length} error={d.hosts.error} />
        <Stat to="/endpoints" label="Endpoints" value={endpoints?.length} error={d.endpoints.error} />
        <Stat to="/history" label="Audits" value={results?.length} error={d.results.error} />
        <Stat to="/exceptions" label="Endpoint exceptions" value={ep?.live.length} error={d.exceptions.error} sub={excSub(ep)} />
        <Stat to="/exceptions?tab=hosts" label="Host exceptions" value={hx?.live.length} error={d.hostExc.error} sub={excSub(hx)} />
      </div>

      {d.problems.length > 0 && <Alert variant="warning"><strong>Some API calls failed</strong>
        <ul className="mb-0 small mt-1">{d.problems.map((p, i) => <li key={i}>{p.message}</li>)}</ul></Alert>}

      <div className="card mb-3"><div className="card-body">
        <div className="d-flex justify-content-between align-items-center mb-2"><h5 className="mb-0">Apps</h5><Link className="small" to="/apps">Manage apps</Link></div>
        {roll && roll.length > 0 && loose.length > 0 && <div className="small text-muted mb-2">
          {loose.length} host{loose.length === 1 ? " isn't" : "s aren't"} linked to any app ({looseEps} endpoint{looseEps === 1 ? "" : "s"}): {loose.slice(0, 6).map(h => h.apiHostName || h.apiHostUrl || "#" + h.id).join(", ")}{loose.length > 6 ? ", …" : ""}</div>}
        {d.apps.missing ? <Empty>The API didn't answer on <code>{CFG.endpoints.apps}</code>. Check the Application endpoints are deployed.</Empty>
          : !roll ? <Empty>Couldn't load apps.</Empty>
          : !roll.length ? <Empty>No apps yet. Add one on the Apps page and link it to its host APIs.</Empty>
          : <div className="table-responsive"><table className="table table-sm table-hover align-middle mb-0">
            <thead><tr><th>App</th><th>Host APIs</th><th className="text-end">Endpoints</th><th style={{ width: "22%" }}></th><th className="text-end">Active</th><th>Last audited</th></tr></thead>
            <tbody>{roll.map(x => (
              <tr key={x.app.id} className="clickable" onClick={() => navigate("/endpoints?app=" + x.app.id)}>
                <td className="fw-semibold">{x.app.applicationName || "#" + x.app.id}{x.app.applicationCode && <span className="small text-muted fw-normal"> {x.app.applicationCode}</span>}
                  {x.app.isActive === false && <> <Badge bg="secondary">Inactive</Badge></>}</td>
                <td>{x.hosts.length ? x.hosts.map(h => <span key={h.id} className={`badge ${hostException(hostExc, h.id) ? "text-bg-warning" : "text-bg-light border"} fw-normal me-1`}>{h.apiHostName || h.apiHostUrl || "#" + h.id}</span>)
                  : <span className="text-muted small">No hosts linked</span>}</td>
                <td className="text-end fs-5 fw-bold">{x.total}</td>
                <td><ProgressBar now={max ? Math.round(x.total / max * 100) : 0} style={{ height: 6, minWidth: 80 }} title={`${x.total} endpoints`} /></td>
                <td className="text-end">{x.active}</td>
                <td className="small text-nowrap">{x.lastAudit ? new Date(x.lastAudit).toLocaleDateString() : <span className="text-muted">never</span>}</td>
              </tr>))}</tbody></table></div>}
      </div></div>

      <div className="row g-3">
        <div className="col-xl-7"><div className="card h-100"><div className="card-body">
          <div className="d-flex justify-content-between align-items-center mb-2"><h5 className="mb-0">Endpoints</h5><Link className="btn btn-sm btn-primary" to="/audit">Run audit</Link></div>
          {endpoints === null ? <Empty>Couldn't load endpoints.</Empty> : <>
            {endpoints.length > 0 && <div className="small text-muted mb-2">{due} active endpoint{due === 1 ? "" : "s"} not audited in the last 7 days. Oldest audits are listed first.</div>}
            <DataTable resource="apiaudit" columns={["id", "description", "url", "environment", "isActive", "lastAuditDate"]}
              rows={endpoints.slice().sort((a, b) => dateMs(a.lastAuditDate) - dateMs(b.lastAuditDate)).slice(0, 10)}
              emptyText="No endpoints yet. Add one on the Endpoints page." onRowClick={r => navigate("/audit?id=" + r.id)} />
          </>}
        </div></div></div>
        <div className="col-xl-5"><div className="card h-100"><div className="card-body">
          <div className="d-flex justify-content-between align-items-center mb-2"><h5 className="mb-0">Recent results</h5><Link className="small" to="/history">View all</Link></div>
          {results === null ? <Empty>Couldn't load results.</Empty>
            : <DataTable resource="apiauditresults" columns={["id", "auditDate", "auditorName", "totalApiEndpoints", "totalEndpointsInsecure"]}
                rows={newestFirst(results).slice(0, 8)} onRowClick={() => navigate("/history")} emptyText="No audits have been run yet." />}
        </div></div></div>
      </div>

      <div className="card mt-3"><div className="card-body">
        <div className="d-flex justify-content-between align-items-center mb-2"><h5 className="mb-0">Active exceptions</h5><Link className="small" to="/exceptions">Manage exceptions</Link></div>
        <div className="row g-4">
          <div className="col-xl-6"><h6 className="text-muted">Host exceptions <span className="fw-normal small">(whole host can't be audited)</span></h6>
            {hx === null ? <Empty>Couldn't load host exceptions.</Empty> : !hx.live.length ? <Empty>No hosts are excepted. Every host can be audited.</Empty>
              : <div className="table-responsive"><table className="table table-sm align-middle mb-0"><thead><tr><th>Host</th><th>Type</th><th>Reason</th><th>Approved by</th><th>Until</th></tr></thead>
                <tbody>{hx.live.map(x => <tr key={x.id}><td><Link to="/hosts">{hostName(x.apiHostId)}</Link></td><td>{x.exceptionType || ""}</td>
                  <td className="small">{x.reason || ""}</td><td className="small">{x.approvedBy || ""}</td><td className="small text-nowrap"><Until x={x} /></td></tr>)}</tbody></table></div>}
          </div>
          <div className="col-xl-6"><h6 className="text-muted">Endpoint exceptions</h6>
            {ep === null ? <Empty>Couldn't load endpoint exceptions.</Empty> : !ep.live.length ? <Empty>No endpoint exceptions in force.</Empty>
              : <div className="table-responsive"><table className="table table-sm align-middle mb-0"><thead><tr><th>Covers</th><th>Reason</th><th>Approved by</th><th>Until</th></tr></thead>
                <tbody>{ep.live.map(x => {
                  const parts = [x.apiAuditId ? epName(x.apiAuditId) : null, x.apiRootUrl && x.apiRootUrl !== "string" ? x.apiRootUrl : null,
                    x.apiEndpointPath && x.apiEndpointPath !== "string" ? <code key="p">{x.apiEndpointPath}</code> : null].filter(Boolean);
                  return <tr key={x.id}><td className="small">{parts.length ? parts.map((p, i) => <span key={i}>{i > 0 && " · "}{p}</span>) : "(no scope)"}</td>
                    <td className="small">{x.reason || ""}</td><td className="small">{x.approvedBy || ""}</td><td className="small text-nowrap"><Until x={x} /></td></tr>;
                })}</tbody></table></div>}
          </div>
        </div>
      </div></div>
    </>
  );
}
