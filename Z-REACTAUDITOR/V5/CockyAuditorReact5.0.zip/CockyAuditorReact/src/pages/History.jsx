// History: every saved audit run, newest first (port of apihistory.html)
import { useState } from "react";
import { Button, Modal } from "react-bootstrap";
import { newestFirst, parseDate } from "../lib/util.js";
import { CrudPage } from "../components/Table.jsx";
import { PageHeader } from "../components/ui.jsx";

export default function History() {
  const [viewing, setViewing] = useState(null);
  const [show, setShow] = useState(false);
  const open = r => { setViewing(r); setShow(true); };
  const r = viewing;
  const Stat = ({ l, v }) => <div className="col-6 col-md-4"><span className="text-muted">{l}:</span> <b>{v ?? "—"}</b></div>;
  return (
    <>
      <PageHeader title="History">Every saved audit run, newest first. Click View to read the full notes.</PageHeader>
      <CrudPage resource="apiauditresults" sort={newestFirst} rowActions={[{ label: "View", onClick: open }]} />
      <Modal show={show} onHide={() => setShow(false)} size="lg" scrollable>
        {r && <>
          <Modal.Header closeButton><Modal.Title as="h5">Audit #{r.id} · {r.auditDate ? parseDate(r.auditDate).toLocaleString() : ""}</Modal.Title></Modal.Header>
          <Modal.Body>
            <div className="row g-2 mb-3 small">
              <Stat l="Auditor" v={[r.auditorName, r.auditorId ? "#" + r.auditorId : ""].filter(Boolean).join(" ")} />
              <Stat l="Hosts" v={`${r.totalApiHosts ?? 0} (${r.apiHostsSecure ?? 0} secure / ${r.apiHostsInsecure ?? 0} insecure)`} />
              <Stat l="Endpoints" v={`${r.totalApiEndpoints ?? 0} (${r.totalEndpointsSecure ?? 0} secure / ${r.totalEndpointsInsecure ?? 0} insecure)`} />
            </div>
            <pre className="bg-light p-3 rounded small mb-0" style={{ whiteSpace: "pre-wrap" }}>{r.notes || "(no notes)"}</pre>
          </Modal.Body>
          <Modal.Footer><Button variant="secondary" onClick={() => setShow(false)}>Close</Button></Modal.Footer>
        </>}
      </Modal>
    </>
  );
}
