// Enterprise(9) logs for one application's linked API set: one +/- accordion section per log category, each with a
// Bootstrap grid of the newest 25 records; click a row for every field (port of enterprise9.html)
import { useCallback, useEffect, useRef, useState } from "react";
import { Accordion, Alert, Badge, Button, ButtonGroup, Form, Modal, useAccordionButton } from "react-bootstrap";
import { useSearchParams } from "react-router-dom";
import CFG from "../config.js";
import api from "../lib/api.js";
import { TAKE, categoriesFor, cfgFor, columnsFor, dateKeyOf, idKeyOf, isParam, namesOf, pathOf, routeText, rowsFrom, segsOf } from "../lib/e9.js";
import { appRollup, byName, dateMs, joinUrl, methodOf, parseDate, titleCase, val } from "../lib/util.js";
import { targetUrl } from "../lib/audit.js";
import { Empty, ErrorBox, LevelBadge, PageHeader, Spinner } from "../components/ui.jsx";

// Where to read a category's records: its registered GET endpoint that lists them (path ends at the set name, no
// {parameters}); else any GET without parameters in the set; else, for a set that isn't registered, its standard route.
function sourcesFor(type, app, hosts) {
  const listable = e => e.isActive !== false && (methodOf(e) || "GET") === "GET" && !segsOf(e).some(isParam);
  const names = cfgFor(type.name) ? namesOf(cfgFor(type.name)) : [type.name.toLowerCase()];
  const endsAtSet = e => names.includes((segsOf(e).pop() || "").toLowerCase());
  let found = type.endpoints.filter(e => listable(e) && endsAtSet(e));
  if (!found.length) found = type.endpoints.filter(listable);
  const byUrl = new Map();
  found.forEach(e => { const u = targetUrl(e, hosts); if (u && !byUrl.has(u.toLowerCase())) byUrl.set(u.toLowerCase(), { url: u, endpoint: e, host: hosts.find(h => h.id === e.apiHostId) }); });
  if (byUrl.size) return [...byUrl.values()];
  if (type.discovered) return [];   // registered, but nothing that lists records (e.g. only POST or GET /{id})
  return app.hosts.filter(h => val(h.apiHostUrl)).map(h => ({ url: joinUrl(val(h.apiHostUrl), type.path || "/api/" + type.name), endpoint: null, host: h, guessed: true }));
}

async function fetchLog(src, token) {
  const ctrl = new AbortController(), t = setTimeout(() => ctrl.abort(), CFG.requestTimeoutMs || 30000);
  const headers = { Accept: "application/json" };
  if (token.trim()) headers.Authorization = "Bearer " + token.trim().replace(/^Bearer\s+/i, "");
  try {
    const res = await fetch(src.url, { headers, cache: "no-store", signal: ctrl.signal });
    const text = await res.text();
    if (!res.ok) throw Object.assign(new Error(`${res.status} ${res.statusText}${text && text.length < 200 ? " - " + text : ""}`), { status: res.status });
    let data;
    try { data = text ? JSON.parse(text) : []; } catch { throw new Error("The answer wasn't JSON."); }
    return rowsFrom(data).filter(r => r && typeof r === "object");
  } catch (e) {
    if (e.name === "AbortError") throw new Error("Timed out.");
    if (e instanceof TypeError) throw new Error(`Couldn't reach it (CORS or the API is down). The API must allow ${location.origin}.`);
    throw e;
  } finally { clearTimeout(t); }
}

async function loadCategory(type, app, hosts, token) {
  const sources = sourcesFor(type, app, hosts), all = [], errors = [];
  await Promise.all(sources.map(async s => {
    try { (await fetchLog(s, token)).forEach(r => all.push({ row: r, src: s })); }
    catch (e) { errors.push({ src: s, message: e.message, status: e.status }); }
  }));
  const rows = all.map(x => x.row);
  const dk = rows.length ? dateKeyOf(rows) : null, ik = rows.length ? idKeyOf(rows) : null;
  all.sort((a, b) => (dk ? dateMs(b.row[dk]) - dateMs(a.row[dk]) : 0) || (ik ? (+b.row[ik] || 0) - (+a.row[ik] || 0) : 0));
  return { type, sources, total: all.length, latest: all.slice(0, TAKE), dateKey: dk, idKey: ik, errors,
    multiHost: new Set(sources.map(s => s.host?.id)).size > 1 };
}

function CountBadge({ r }) {
  if (!r) return <Badge bg="light" text="dark" className="border" title="Not loaded yet">…</Badge>;
  if (!r.sources.length) return <Badge bg="light" text="dark" className="border" title="Nothing to read">–</Badge>;
  if (r.errors.length && !r.total) return <Badge bg="danger" title={r.errors[0].message}>!</Badge>;
  return <Badge bg={r.total ? "primary" : "light"} text={r.total ? undefined : "dark"} className={r.total ? "" : "border"} title={`${r.total} record(s)`}>{r.total}</Badge>;
}

function Cell({ k, v, dk }) {
  if (v == null || v === "") return <span className="text-muted">—</span>;
  if (k === dk) { const d = parseDate(v); return d ? d.toLocaleString() : String(v); }
  if (typeof v === "boolean") return v ? "Yes" : "No";
  if (/^(level|severity|loglevel)$/i.test(k)) return <LevelBadge v={v} />;
  return String(v).slice(0, 200);
}

// Accordion header: +/- toggle, category, route, count
function CategoryHeader({ eventKey, type, r, open }) {
  const toggle = useAccordionButton(eventKey);
  return (
    <h2 className="accordion-header">
      <button type="button" className={`accordion-button ${open ? "" : "collapsed"}`} onClick={toggle} aria-expanded={open}>
        <span className="pm" aria-hidden="true" />
        <span className="flex-grow-1"><span className="fw-semibold">{type.label || type.name}</span>
          <span className="d-block small text-muted font-monospace">GET {routeText(type)}{type.discovered ? ` · ${type.endpoints.length} endpoint${type.endpoints.length === 1 ? "" : "s"}` : " · not registered"}</span></span>
        <span className="ms-2 me-1"><CountBadge r={r} /></span>
      </button>
    </h2>
  );
}

function CategoryBody({ r, onRow }) {
  if (!r) return <Spinner />;
  const setEps = r.type.endpoints;
  return (
    <>
      <div className="d-flex flex-wrap justify-content-between align-items-baseline gap-2 mb-2">
        <span className="small">{r.latest.length > 0 && <>Newest <b>{r.latest.length}</b> of <b>{r.total}</b> records</>}</span>
        <span className="src-note">{r.dateKey ? `Sorted by ${titleCase(r.dateKey)}, newest first` : r.idKey ? `Sorted by ${r.idKey}, highest first` : ""}</span>
      </div>
      <div className="src-note mb-2">
        {r.sources.length ? r.sources.map((s, i) => <div key={i}><code>GET {s.url}</code>{s.endpoint
          ? <span className="text-muted"> (endpoint #{s.endpoint.id})</span> : <span className="text-warning-emphasis"> (not registered; tried the standard route)</span>}</div>)
          : r.type.discovered ? <span className="text-warning-emphasis">None of this set's endpoints lists records (a GET without {"{parameters}"}), so there's nothing to read.</span>
          : <span className="text-warning-emphasis">This application has no hosts linked, so there is nowhere to read its logs from. Link hosts on the Apps page.</span>}
      </div>
      {setEps.length > 0 && <details className="src-note mb-2"><summary>{setEps.length} registered endpoint{setEps.length === 1 ? "" : "s"} in this set</summary>
        {setEps.map(e => <div key={e.id}><code>{methodOf(e) || "?"} {pathOf(e)}</code> <span className="text-muted">#{e.id}</span></div>)}</details>}
      {r.errors.map((e, i) => (
        <Alert key={i} variant={e.status === 401 || e.status === 403 ? "warning" : "danger"} className="small py-2 mb-2">
          <b>{e.src.host?.apiHostName || e.src.url}</b>: {e.message}
          {(e.status === 401 || e.status === 403) && " This log needs authentication. Paste a bearer token above and Reload."}
          {e.status === 404 && ` This application doesn't expose ${r.type.name} at that address.`}
        </Alert>))}
      {r.latest.length > 0 ? (() => {
        const cols = columnsFor(r.latest.map(x => x.row), r.dateKey, r.idKey);
        return (
          <div className="table-responsive"><table className="table table-sm table-striped table-bordered table-hover align-middle log-table mb-0">
            <thead className="table-light"><tr>{r.multiHost && <th>Host</th>}{cols.map(k => <th key={k}>{titleCase(k)}</th>)}</tr></thead>
            <tbody>{r.latest.map((x, i) => (
              <tr key={i} className="clickable" onClick={() => onRow(r, x)}>
                {r.multiHost && <td>{x.src.host?.apiHostName || ""}</td>}
                {cols.map(k => <td key={k}><Cell k={k} v={x.row[k]} dk={r.dateKey} /></td>)}
              </tr>))}</tbody>
          </table></div>);
      })() : !r.errors.length && r.sources.length > 0 && <Empty>No {r.type.name} records yet.</Empty>}
    </>
  );
}

export default function Enterprise9() {
  const [params, setParams] = useSearchParams();
  const [base, setBase] = useState(null);       // { rollup, hosts }
  const [error, setError] = useState(null);
  const [token, setToken] = useState("");
  const [results, setResults] = useState({});   // `${appId}|${name}` -> result
  const [open, setOpen] = useState([]);         // open accordion keys
  const [checking, setChecking] = useState(null);
  const [detail, setDetail] = useState(null);
  const [showDetail, setShowDetail] = useState(false);
  const loading = useRef(new Set());

  useEffect(() => {
    Promise.all([api.list("apps"), api.list("apphosts"), api.list("apihosts"), api.list("apiaudit")])
      .then(([apps, links, hosts, endpoints]) => setBase({ rollup: appRollup(apps, links, hosts, endpoints).sort((a, b) => byName(a.app, b.app)), hosts }))
      .catch(setError);
  }, []);

  const appId = params.get("app");
  const current = base ? base.rollup.find(x => String(x.app.id) === appId) || base.rollup[0] : null;
  const types = current ? categoriesFor(current.endpoints) : [];
  const key = t => `${current.app.id}|${t.name}`;

  const load = useCallback(async (t, force = false) => {
    const k = `${current.app.id}|${t.name}`;
    if (!force && (results[k] || loading.current.has(k))) return;
    loading.current.add(k);
    if (force) setResults(r => { const n = { ...r }; delete n[k]; return n; });
    const r = await loadCategory(t, current, base.hosts, token);
    loading.current.delete(k);
    setResults(x => ({ ...x, [k]: r }));
  }, [current, base, token, results]);

  // Open the requested category (?log=), else the first registered one, whenever the app changes
  useEffect(() => {
    if (!current) return;
    const wanted = params.get("log");
    const first = types.find(t => t.name.toLowerCase() === String(wanted || "").toLowerCase()) || types.find(t => t.discovered);
    setOpen(first ? [first.name] : []);
    if (!appId || String(current.app.id) !== appId || wanted) setParams({ app: String(current.app.id) }, { replace: true });
  }, [current?.app.id]);   // eslint-disable-line react-hooks/exhaustive-deps

  // Load a category when its section is opened
  useEffect(() => { if (current) types.filter(t => open.includes(t.name)).forEach(t => load(t)); }, [open, current?.app.id]);   // eslint-disable-line react-hooks/exhaustive-deps

  async function checkAll() {
    let n = 0; setChecking(`0/${types.length}`);
    await Promise.all(types.map(async t => {
      const r = await loadCategory(t, current, base.hosts, token);
      setResults(x => ({ ...x, [key(t)]: r }));
      setChecking(`${++n}/${types.length}`);
    }));
    setChecking(null);
  }
  function reloadAll() {
    setResults({});
    loading.current.clear();
    types.filter(t => open.includes(t.name)).forEach(t => loadCategory(t, current, base.hosts, token).then(r => setResults(x => ({ ...x, [key(t)]: r }))));
  }

  if (error) return <><PageHeader title="Enterprise(9) Logs" /><ErrorBox error={error} onRetry={() => location.reload()} /></>;
  if (!base) return <><PageHeader title="Enterprise(9) Logs" /><Spinner text="Loading applications…" /></>;

  const nFound = types.filter(t => t.discovered).length, nEps = types.reduce((n, t) => n + t.endpoints.length, 0);
  const row = detail?.x.row;
  const when = detail && detail.r.dateKey && parseDate(row[detail.r.dateKey]);
  const fmt = v => v == null || v === "" ? <span className="text-muted">—</span>
    : typeof v === "object" ? <pre className="mb-0 small">{JSON.stringify(v, null, 2)}</pre>
    : typeof v === "string" && /^\d{4}-\d{2}-\d{2}T/.test(v) && parseDate(v) ? <>{parseDate(v).toLocaleString()} <span className="text-muted small">{v}</span></>
    : String(v);

  return (
    <>
      <PageHeader title="Enterprise(9) Logs">Every endpoint with <b>log</b> in its path is part of Enterprise(9). Pick an application to see its log categories (found among its registered endpoints) and the newest records of each; click a row for the full detail.</PageHeader>
      <div className="card mb-3"><div className="card-body">
        <div className="d-flex flex-wrap gap-2 align-items-end">
          <div><Form.Label className="small mb-1" htmlFor="appSel">Application</Form.Label>
            <Form.Select size="sm" id="appSel" style={{ minWidth: 260 }} value={current ? String(current.app.id) : ""} onChange={e => setParams({ app: e.target.value }, { replace: true })}>
              {base.rollup.map(x => <option key={x.app.id} value={x.app.id}>{x.app.applicationName || "App #" + x.app.id}{x.hosts.length ? "" : " (no hosts linked)"}</option>)}
            </Form.Select></div>
          <div><Form.Label className="small mb-1" htmlFor="token">Bearer token <span className="text-muted">(only if the logs need one)</span></Form.Label>
            <Form.Control size="sm" id="token" type="password" autoComplete="off" style={{ minWidth: 240 }} placeholder="Not stored" value={token} onChange={e => setToken(e.target.value)} /></div>
          <Button size="sm" variant="outline-primary" id="reload" onClick={reloadAll} disabled={!current}>Reload</Button>
          <Button size="sm" variant="outline-secondary" id="loadAll" onClick={checkAll} disabled={!current || !!checking}>{checking ? `Checking… ${checking}` : "Check all logs"}</Button>
        </div>
      </div></div>

      <div id="body">
        {!current ? <Empty>No applications yet. Add one on the Apps page and link its hosts.</Empty>
          : !types.length ? <Empty>No Enterprise(9) logs for this application: none of its endpoints has "log" in its path, and no standard categories are listed in config.js.</Empty>
          : <>
            <div className="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
              <div className="small text-muted"><b>{nFound}</b> Enterprise(9) log categor{nFound === 1 ? "y" : "ies"} registered for <b>{current.app.applicationName || "this application"}</b>{" "}
                ({nEps} endpoint{nEps === 1 ? "" : "s"}){types.length > nFound ? `, plus ${types.length - nFound} standard categor${types.length - nFound === 1 ? "y" : "ies"} it hasn't registered (dimmed)` : ""}.</div>
              <ButtonGroup size="sm">
                <Button variant="outline-secondary" id="expandAll" onClick={() => setOpen(types.map(t => t.name))}>+ Expand all</Button>
                <Button variant="outline-secondary" id="collapseAll" onClick={() => setOpen([])}>− Collapse all</Button>
              </ButtonGroup>
            </div>
            <Accordion className="e9-acc" id="e9acc" alwaysOpen activeKey={open}
              onSelect={k => setOpen(Array.isArray(k) ? k : k == null ? [] : [k])}>
              {types.map(t => (
                <Accordion.Item key={t.name} eventKey={t.name} className={t.discovered ? "" : "not-registered"}>
                  <CategoryHeader eventKey={t.name} type={t} r={results[key(t)]} open={open.includes(t.name)} />
                  <Accordion.Body>{open.includes(t.name) && <CategoryBody r={results[key(t)]} onRow={(r, x) => { setDetail({ r, x }); setShowDetail(true); }} />}</Accordion.Body>
                </Accordion.Item>))}
            </Accordion>
          </>}
      </div>

      <Modal show={showDetail} onHide={() => setShowDetail(false)} size="lg" scrollable id="detailModal">
        {detail && <>
          <Modal.Header closeButton><Modal.Title as="h5">{detail.r.type.label || detail.r.type.name}{detail.r.idKey ? " #" + row[detail.r.idKey] : ""}{when ? " · " + when.toLocaleString() : ""}</Modal.Title></Modal.Header>
          <Modal.Body>
            <div className="detail-grid" id="detailGrid">
              <div className="k">Source</div><div className="v">{detail.x.src.host?.apiHostName || ""} <span className="text-muted small">{detail.x.src.url}</span></div>
              {Object.entries(row).map(([k, v]) => <Fragment2 key={k} k={titleCase(k)} v={fmt(v)} />)}
            </div>
            <details className="mt-3"><summary className="small text-muted">Raw JSON</summary><pre className="bg-light p-2 rounded small mb-0">{JSON.stringify(row, null, 2)}</pre></details>
          </Modal.Body>
        </>}
      </Modal>
    </>
  );
}
const Fragment2 = ({ k, v }) => <><div className="k">{k}</div><div className="v">{v}</div></>;
