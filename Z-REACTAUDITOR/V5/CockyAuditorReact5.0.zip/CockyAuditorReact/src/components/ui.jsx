// Small presentational pieces shared by the pages
import { Alert, Badge, Button, Spinner as BsSpinner } from "react-bootstrap";
import { DATE_RE, parseDate, refTarget, refLabel } from "../lib/util.js";
import { refRows } from "../lib/api.js";

export const Spinner = ({ text = "Loading…", className = "py-4" }) => (
  <div className={`text-muted ${className}`}><BsSpinner animation="border" size="sm" className="me-2" />{text}</div>
);

export const Empty = ({ children }) => <div className="empty">{children}</div>;

export function ErrorBox({ error, onRetry, title = "Couldn't load data." }) {
  return (
    <Alert variant="danger" className="d-flex justify-content-between align-items-start gap-3">
      <div><strong>{title}</strong><div className="small mt-1">{error?.message || String(error)}</div></div>
      {onRetry && <Button size="sm" variant="outline-danger" onClick={onRetry}>Retry</Button>}
    </Alert>
  );
}

export const MethodBadge = ({ method }) => (
  <span className={`badge method-${String(method || "get").toLowerCase()}`}>{method}</span>
);

export const VerdictBadge = ({ verdict }) => ({
  pass: <Badge bg="success">Pass</Badge>,
  warn: <Badge bg="warning" text="dark">Warning</Badge>,
  fail: <Badge bg="danger">Fail</Badge>,
  running: <Badge bg="info" text="dark">Running…</Badge>
}[verdict] || null);

const Dash = () => <span className="text-muted">—</span>;

// Same display rules as fmtValue in the HTML version
export function FmtValue({ v, type }) {
  if (type === "password") return v ? "••••••" : <Dash />;
  const ref = refTarget(type);
  if (ref && v != null && v !== "") {
    const hit = refRows(ref).find(r => String(r.id) === String(v));
    return hit ? refLabel(hit) : `#${v}`;
  }
  if (v === null || v === undefined || v === "") return <Dash />;
  if (type === "bool" || typeof v === "boolean") return v ? <Badge bg="success">Yes</Badge> : <Badge bg="secondary">No</Badge>;
  if (type === "date" || (typeof v === "string" && DATE_RE.test(v))) {
    const d = parseDate(v);
    if (d) return d.toLocaleString();
  }
  const s = typeof v === "object" ? JSON.stringify(v) : String(v);
  return s.length > 60 ? <span title={s}>{s.slice(0, 57)}…</span> : s;
}

// "Expired" / "No expiry" badges for exception expiration dates
export function ExpiryCell({ v }) {
  if (!v) return <Badge bg="info" text="dark">No expiry</Badge>;
  const d = parseDate(v);
  return <>{d ? d.toLocaleString() : String(v)}{d && d < new Date() && <> <Badge bg="danger">Expired</Badge></>}</>;
}

export const PageHeader = ({ title, children }) => (
  <>
    <h2>{title}</h2>
    {children && <div className="page-sub">{children}</div>}
  </>
);

// Enterprise(9) log levels, colored
export function LevelBadge({ v }) {
  const s = String(v).toLowerCase();
  const bg = /(err|fatal|crit|fail)/.test(s) ? "danger" : /warn/.test(s) ? "warning" : /(info|notice)/.test(s) ? "info" : "secondary";
  return <Badge bg={bg} text={bg === "warning" || bg === "info" ? "dark" : undefined}>{String(v)}</Badge>;
}
