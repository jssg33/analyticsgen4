// Sidebar layout for the signed-in pages, and the route guard
import { useEffect, useSyncExternalStore } from "react";
import { Link, NavLink, Navigate, Outlet, useLocation, useNavigate } from "react-router-dom";
import CFG from "../config.js";
import { currentUser, isSignedIn, onAuthChange, signOut } from "../lib/auth.js";

export const PAGES = [
  { path: "/dashboard",   label: "Dashboard" },
  { path: "/apps",        label: "Apps" },
  { path: "/hosts",       label: "Hosts" },
  { path: "/endpoints",   label: "Endpoints" },
  { path: "/audit",       label: "Run Audit" },
  { path: "/exceptions",  label: "Exceptions" },
  { path: "/history",     label: "History" },
  { path: "/enterprise9", label: "Enterprise(9)" }
];

// Re-renders when the sign-in state changes (this tab or another tab)
const subscribe = fn => onAuthChange(fn);
const snapshot = () => (isSignedIn() ? "in:" : "out:") + (currentUser().username || "");
export const useAuth = () => { const s = useSyncExternalStore(subscribe, snapshot); return { signedIn: s.startsWith("in:"), username: s.slice(s.indexOf(":") + 1) }; };

// Every page except /login: role must be auditor and userid not 901, else go to login (and come back after)
export function RequireAuth({ children }) {
  const { signedIn } = useAuth();
  const loc = useLocation();
  if (!signedIn) return <Navigate to={`/login?next=${encodeURIComponent(loc.pathname + loc.search)}`} replace />;
  return children;
}

// Browser tab title: "Hosts · CockyAuditor"
export function useTitle(title) {
  useEffect(() => { document.title = title ? `${title} · ${CFG.appName}` : CFG.appName; }, [title]);
}

export default function Layout() {
  const { username } = useAuth();
  const navigate = useNavigate();
  const loc = useLocation();
  useTitle(PAGES.find(p => loc.pathname.startsWith(p.path))?.label);
  const apiName = (() => { try { return new URL(CFG.apiBaseUrl).host.split(".")[0]; } catch { return ""; } })();
  return (
    <div className="app">
      <nav className="sidebar">
        <Link className="brand" to="/" title="Home">{CFG.appName}</Link>
        {PAGES.map(p => <NavLink key={p.path} to={p.path} className={({ isActive }) => isActive ? "active" : ""}>{p.label}</NavLink>)}
        <div className="user-box">{username}
          <button type="button" className="btn-link-plain" id="signOut" onClick={() => { signOut(); setTimeout(() => navigate("/login", { replace: true })); }}>Sign out</button>
        </div>
        <div className="api-note" title={CFG.apiBaseUrl}>
          Build {CFG.version}{CFG.builds?.[0] ? " · " + CFG.builds[0].title : ""}<br />API: {apiName}
          {CFG.copyright && <><br /><span className="copy">{CFG.copyright}</span></>}
        </div>
      </nav>
      <main className="content" id="page"><Outlet /></main>
    </div>
  );
}
