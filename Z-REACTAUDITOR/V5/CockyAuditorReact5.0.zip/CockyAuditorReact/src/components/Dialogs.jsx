// Dialogs that pages can await, like the HTML version's promise-returning dialogs:
//   const d = useDialogs();
//   if (await d.confirm({ title, body })) ...
//   const saved = await d.recordForm("apihosts", host, rows);
//   const c = await d.credentials(host, message, lastUser);
//   const choice = await d.confirmChanges(host, parsed, missing, adopt);   // "add" | "skip" | null
//   const changed = await d.swagger(host);
import { createContext, useCallback, useContext, useMemo, useRef, useState } from "react";
import { Button, Form, Modal } from "react-bootstrap";
import RecordForm from "./RecordForm.jsx";
import SwaggerWizard from "./SwaggerWizard.jsx";
import { MethodBadge } from "./ui.jsx";

const DialogCtx = createContext(null);
export const useDialogs = () => useContext(DialogCtx);

// Wraps a dialog body: keeps it mounted until the close animation ends, then resolves
function Shell({ render, resolve, size, backdrop }) {
  const [show, setShow] = useState(true);
  const result = useRef(null);
  const done = r => { result.current = r; setShow(false); };
  return (
    <Modal show={show} onHide={() => done(null)} onExited={() => resolve(result.current)} size={size} backdrop={backdrop}
      keyboard={backdrop !== "static"} scrollable>
      {render(done)}
    </Modal>
  );
}

export function DialogProvider({ children }) {
  const [stack, setStack] = useState([]);
  const open = useCallback((render, opts = {}) => new Promise(resolve => {
    const id = Math.random().toString(36).slice(2);
    setStack(s => [...s, { id, render, opts, resolve: r => { setStack(x => x.filter(d => d.id !== id)); resolve(r); } }]);
  }), []);

  const api = useMemo(() => ({
    confirm: ({ title = "Are you sure?", body, okText = "OK", variant = "primary" }) => open(done => (
      <>
        <Modal.Header closeButton><Modal.Title as="h5">{title}</Modal.Title></Modal.Header>
        <Modal.Body>{body}</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => done(false)}>Cancel</Button>
          <Button variant={variant} onClick={() => done(true)}>{okText}</Button>
        </Modal.Footer>
      </>
    )).then(r => !!r),

    recordForm: (resource, record, sampleRows = [], defaults = {}, opts = {}) =>
      open(done => <RecordForm resource={resource} record={record} sampleRows={sampleRows} defaults={defaults} opts={opts} done={done} />, { size: "lg" }),

    credentials: (host, message = "", lastUser = "") => open(done => <CredentialsDialog host={host} message={message} lastUser={lastUser} done={done} />),

    confirmChanges: (host, parsed, missing, adopt) =>
      open(done => <ConfirmChanges host={host} parsed={parsed} missing={missing} adopt={adopt} done={done} />, { size: "lg", backdrop: "static" }),

    swagger: host => open(done => <SwaggerWizard host={host} done={done} />, { size: "xl", backdrop: "static" }).then(r => !!r)
  }), [open]);

  return (
    <DialogCtx.Provider value={api}>
      {children}
      {stack.map(d => <Shell key={d.id} render={d.render} resolve={d.resolve} size={d.opts.size} backdrop={d.opts.backdrop} />)}
    </DialogCtx.Provider>
  );
}

// Swagger login for a host. Resolves { user, pass, save } or null.
function CredentialsDialog({ host, message, lastUser, done }) {
  const blank = v => v == null || String(v).trim() === "" || String(v).trim().toLowerCase() === "string";
  const [user, setUser] = useState(lastUser || (blank(host.swaggerUsername) ? "" : host.swaggerUsername));
  const [pass, setPass] = useState("");
  const [save, setSave] = useState(true);
  return (
    <Form onSubmit={e => { e.preventDefault(); done({ user: user.trim(), pass, save }); }}>
      <Modal.Header closeButton><Modal.Title as="h5">Swagger login</Modal.Title></Modal.Header>
      <Modal.Body>
        <p className="small text-muted mb-2">{host.apiHostName || ""} · {host.apiHostUrl}</p>
        {message && <div className="alert alert-warning small py-2">{message}</div>}
        <Form.Label className="small mb-1" htmlFor="cr_user">Username</Form.Label>
        <Form.Control id="cr_user" className="mb-2" autoComplete="off" value={user} onChange={e => setUser(e.target.value)} autoFocus={!user} />
        <Form.Label className="small mb-1" htmlFor="cr_pass">Password</Form.Label>
        <Form.Control id="cr_pass" className="mb-2" type="password" autoComplete="new-password" value={pass} onChange={e => setPass(e.target.value)} autoFocus={!!user} />
        <Form.Check id="cr_save" className="small" label="Save on the host for next time" checked={save} onChange={e => setSave(e.target.checked)} />
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={() => done(null)}>Cancel</Button>
        <Button type="submit">Continue</Button>
      </Modal.Footer>
    </Form>
  );
}

// Before Audit host writes anything: how many endpoint records will be inserted (and linked), and ask.
function ConfirmChanges({ host, parsed, missing, adopt, done }) {
  const total = parsed.endpoints.length, have = total - missing.length;
  const Tile = ({ n, label, cls = "" }) => (
    <div className="col"><div className="border rounded py-2"><div className={`fs-3 fw-bold ${cls}`}>{n}</div><div className="small text-muted">{label}</div></div></div>
  );
  return (
    <>
      <Modal.Header closeButton><Modal.Title as="h5">Add new endpoints?</Modal.Title></Modal.Header>
      <Modal.Body>
        <p className="mb-2">Swagger for <b>{host.apiHostName || host.apiHostUrl}</b> lists <b>{total}</b> operations. <b>{have}</b> are already registered and won't be added again.</p>
        <div className="row g-2 text-center mb-3" id="ins_counts">
          <Tile n={missing.length} label="new records to insert" cls={missing.length ? "text-success" : ""} />
          <Tile n={adopt.length} label="existing records to link to this host" />
          <Tile n={have} label="already registered" />
        </div>
        {missing.length > 0 && <>
          <h6 className="small text-uppercase text-muted">Will be inserted</h6>
          <div className="table-responsive" style={{ maxHeight: 260 }}><table className="table table-sm mb-2"><tbody>
            {missing.map(o => <tr key={o.method + o.path}><td><MethodBadge method={o.method} /></td><td className="font-monospace small">{o.path}</td><td className="small">{o.tag}</td></tr>)}
          </tbody></table></div>
        </>}
        {adopt.length > 0 && <div className="small text-muted">{adopt.length} registered endpoint(s) match these operations but aren't linked to this host; they'll get <code>apiHostId {host.id}</code>. No copies are made.</div>}
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" className="me-auto" onClick={() => done(null)}>Cancel</Button>
        <Button variant="outline-primary" data-choice="skip" onClick={() => done("skip")}>Audit without adding</Button>
        <Button data-choice="add" id="ins_add" onClick={() => done("add")}>
          {missing.length ? `Insert ${missing.length} record${missing.length === 1 ? "" : "s"} & audit` : `Link ${adopt.length} & audit`}
        </Button>
      </Modal.Footer>
    </>
  );
}
