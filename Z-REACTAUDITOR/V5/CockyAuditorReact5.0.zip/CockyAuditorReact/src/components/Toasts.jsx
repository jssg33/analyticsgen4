// Toast notifications (bottom right), available anywhere through useToast()
import { createContext, useCallback, useContext, useState } from "react";
import { Toast, ToastContainer } from "react-bootstrap";

const ToastCtx = createContext(() => {});
export const useToast = () => useContext(ToastCtx);

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const toast = useCallback((message, type = "success") => {
    const id = Math.random().toString(36).slice(2);
    setToasts(t => [...t, { id, message, type }]);
  }, []);
  const close = id => setToasts(t => t.filter(x => x.id !== id));
  return (
    <ToastCtx.Provider value={toast}>
      {children}
      <ToastContainer position="bottom-end" className="p-3 position-fixed">
        {toasts.map(t => (
          <Toast key={t.id} bg={t.type} autohide delay={t.type === "danger" ? 8000 : 3000} onClose={() => close(t.id)}>
            <div className="d-flex">
              <Toast.Body className={["warning", "info", "light"].includes(t.type) ? "" : "text-white"}>{t.message}</Toast.Body>
              <button type="button" className={`btn-close ${["warning", "info", "light"].includes(t.type) ? "" : "btn-close-white"} me-2 m-auto`} aria-label="Close" onClick={() => close(t.id)} />
            </div>
          </Toast>
        ))}
      </ToastContainer>
    </ToastCtx.Provider>
  );
}
