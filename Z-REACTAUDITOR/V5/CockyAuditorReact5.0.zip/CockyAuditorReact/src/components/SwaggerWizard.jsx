// "Add API from Swagger" / "Sync Swagger" wizard (port of SwaggerImport.open in swagger-import.js).
// Step 1: API URL + Swagger login (or pasted swagger.json). Step 2: review every operation, which are new and which
// are already registered (the same no-duplicates matching as Audit host). Step 3: import.
// Resolves true (through done) if anything was changed.
import { useMemo, useState } from "react";
import { Alert, Button, Form, InputGroup, Modal, ProgressBar } from "react-bootstrap";
import { Link } from "react-router-dom";
import SCHEMA from "../schema.js";
import api from "../lib/api.js";
import { dateMs, titleCase } from "../lib/util.js";
import {
  DETAIL_FIELDS, HOST_ONLY, ZERO_IS_UNSET, copyable, createWithRetry, detailsFor, dupeNote, endpointRecord,
  findSpec, hostDefaults, parseSpec, reconcile, trimSlash
} from "../lib/swagger.js";
import { MethodBadge, Spinner } from "./ui.jsx";

const blank = v => v == null || String(v).trim() === "" || String(v).trim().toLowerCase() === "string";

export default function SwaggerWizard({ host = null, done }) {
  const [step, setStep] = useState(1);
  const [changed, setChanged] = useState(false);
  // step 1
  const [root, setRoot] = useState(host?.apiHostUrl || "");
  const [name, setName] = useState(host?.apiHostName || "");
  const [user, setUser] = useState(blank(host?.swaggerUsername) ? "" : host.swaggerUsername);
  const [pass, setPass] = useState(blank(host?.swaggerPassword) ? "" : host.swaggerPassword);
  const [showPass, setShowPass] = useState(false);
  const [specPath, setSpecPath] = useState("/swagger/v1/swagger.json");
  const [saveLogin, setSaveLogin] = useState(true);
  const [paste, setPaste] = useState("");
  const [log, setLog] = useState("");
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);
  // step 2
  const [parsed, setParsed] = useState(null);
  const [existing, setExisting] = useState([]);
  const [targetHost, setTargetHost] = useState(host);
  const [rec, setRec] = useState(null);
  const [picks, setPicks] = useState(new Set());
  const [filter, setFilter] = useState("");
  const [tplId, setTplId] = useState("");
  const [edits, setEdits] = useState({});
  const [saveHost, setSaveHost] = useState(true);
  const [deact, setDeact] = useState(true);
  // step 3
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState("");
  const [result, setResult] = useState(null);

  async function doFetch() {
    setErr(null);
    let r = root.trim();
    if (!/^https?:\/\//i.test(r)) { setErr("Enter the API URL, starting with https://"); return; }
    r = trimSlash(r);
    setBusy(true);
    let p;
    try {
      let spec, url;
      if (paste.trim()) { spec = JSON.parse(paste.trim()); url = r + "/swagger.json"; setLog("Using the pasted swagger.json."); }
      else ({ spec, url } = await findSpec(r, specPath.trim(), user.trim(), pass, setLog));
      p = parseSpec(spec, url);
      if (!p.origin || paste.trim()) { const u = new URL(r); p.origin = u.origin; if (!p.basePath) p.basePath = trimSlash(u.pathname); p.rootUrl = trimSlash(p.origin + p.basePath); }
      setLog(`Loaded ${url}`);
    } catch (e) {
      setBusy(false); setLog("");
      setErr(<>{e.message}{e.kind === "network" && <div className="mt-1">You can also open the swagger.json link in a new tab, save it, and upload it below.</div>}</>);
      return;
    }
    // What's already registered?
    let hosts, eps;
    try { [hosts, eps] = await Promise.all([api.list("apihosts"), api.list("apiaudit")]); }
    catch (e) { setBusy(false); setErr("Couldn't load current hosts/endpoints: " + e.message); return; }
    const th = host || hosts.find(h => trimSlash(h.apiHostUrl).toLowerCase() === p.origin.toLowerCase()) || null;
    const rc = reconcile(p, th, eps);
    setParsed(p); setExisting(eps); setTargetHost(th); setRec(rc);
    setPicks(new Set(p.endpoints.filter(o => !o.exists).map(o => o.key)));
    // Template: default to the most recently modified endpoint on this host that has details filled in
    const richness = e => Object.keys(copyable(e)).length;
    const cands = eps.filter(e => richness(e) > 3)
      .sort((a, b) => (b.apiHostId === th?.id) - (a.apiHostId === th?.id) || dateMs(b.modifiedDate) - dateMs(a.modifiedDate));
    setTplId(cands.length ? String(cands[0].id) : "");
    setEdits({});
    setBusy(false); setStep(2);
  }

  const richness = e => Object.keys(copyable(e)).length;
  const candidates = useMemo(() => existing.filter(e => richness(e) > 3)
    .sort((a, b) => (b.apiHostId === targetHost?.id) - (a.apiHostId === targetHost?.id) || dateMs(b.modifiedDate) - dateMs(a.modifiedDate)),
  [existing, targetHost]);
  const tpl = existing.find(e => String(e.id) === tplId);
  const baseDetails = useMemo(() => detailsFor(targetHost, tpl), [targetHost, tpl]);
  const details = () => {
    const d = { ...baseDetails };
    for (const [k, raw] of Object.entries(edits)) {
      const v = String(raw).trim();
      if (v === "") delete d[k];
      else d[k] = SCHEMA.apiaudit.fields[k] === "number" ? Number(v) || 0 : v;
    }
    return d;
  };

  const shown = parsed ? parsed.endpoints.filter(o => !filter.trim() || `${o.method} ${o.path} ${o.tag} ${o.summary}`.toLowerCase().includes(filter.trim().toLowerCase())) : [];
  const nPicked = parsed ? parsed.endpoints.filter(o => picks.has(o.key) && !o.exists).length : 0;
  const togglePick = (key, on) => setPicks(s => { const n = new Set(s); on ? n.add(key) : n.delete(key); return n; });
  const allShownPicked = shown.filter(o => !o.exists).every(o => picks.has(o.key));

  async function doImport() {
    const chosen = parsed.endpoints.filter(o => picks.has(o.key) && !o.exists);
    const deactIds = deact && rec.notInSwagger.length ? rec.notInSwagger.map(e => e.id) : [];
    if (!chosen.length && !deactIds.length) { setErr("Nothing selected to import."); return; }
    setErr(null); setStep(3);
    const total = chosen.length + deactIds.length + 1;
    let n = 0; const tick = () => setProgress(Math.round(++n / total * 100));
    const failures = [], filled = new Set();
    const hostName = name.trim() || parsed.title || new URL(parsed.origin).hostname;

    // 1. host
    setStatus(targetHost ? "Updating host…" : "Creating host…");
    let th = targetHost;
    const now = new Date().toISOString();
    try {
      if (th) {
        const upd = { ...th, apiHostName: th.apiHostName || hostName, isSecure: parsed.origin.startsWith("https:") };
        if (saveLogin) Object.assign(upd, { swaggerUsername: user.trim() || null, swaggerPassword: pass || null });
        await api.update("apihosts", th.id, upd); th = upd;
      } else {
        const body = { apiHostName: hostName, apiHostUrl: parsed.origin, swaggerUsername: saveLogin ? user.trim() || null : null, swaggerPassword: saveLogin ? pass || null : null,
          isSecure: parsed.origin.startsWith("https:"), lastAuditDate: null, lastAuditId: 0, active: true, createdDate: now };
        const created = await createWithRetry("apihosts", body, filled);
        th = created && created.id != null ? created
          : (await api.list("apihosts")).find(h => trimSlash(h.apiHostUrl).toLowerCase() === parsed.origin.toLowerCase());
        if (!th) throw new Error("The host was created but its id couldn't be found.");
      }
      setChanged(true);
    } catch (e) { setResult({ fatal: `Couldn't save the host: ${e.message}` }); return; }
    tick();

    // 2. Re-check against the database right now, so nothing added since the preview is duplicated
    setStatus("Checking which endpoints are already registered…");
    let linked = 0, skipped = 0, eps;
    try {
      eps = await api.list("apiaudit");
      const fresh = reconcile(parsed, th, eps);
      const newKeys = new Set(fresh.missing.map(o => o.key));
      const before = chosen.length;
      for (let k = chosen.length - 1; k >= 0; k--) if (chosen[k].exists || !newKeys.has(chosen[k].key)) chosen.splice(k, 1);
      skipped = before - chosen.length;
      for (const e of fresh.adopt) {
        try { await api.update("apiaudit", e.id, { ...e, apiHostId: th.id, modifiedDate: new Date().toISOString() }); linked++; }
        catch (e2) { failures.push(`Linking #${e.id}: ${e2.message}`); }
      }
    } catch (e) { setResult({ fatal: `Couldn't re-check existing endpoints, so nothing was imported: ${e.message}` }); return; }

    // 3. endpoints (a few at a time), with the shared details copied in
    const det = details();
    if (saveHost) {
      const hostFields = SCHEMA.apihosts.fields, fill = {};
      for (const [k, v] of Object.entries(det)) {
        if (!(k in hostFields) || HOST_ONLY.has(k)) continue;
        const cur = th[k];
        if (blank(cur) || (cur === 0 && ZERO_IS_UNSET.test(k)) || cur === false) fill[k] = v;
      }
      if (Object.keys(fill).length) {
        try { const upd = { ...th, ...fill }; await api.update("apihosts", th.id, upd); th = upd; }
        catch (e) { failures.push("Saving details on the host: " + e.message); }
      }
    }
    let created = 0, i = 0;
    const worker = async () => {
      while (i < chosen.length) {
        const o = chosen[i++];
        setStatus(`Importing ${created + failures.length + 1} of ${chosen.length}: ${o.method} ${o.path}`);
        try { await createWithRetry("apiaudit", endpointRecord(o, parsed, th, det), filled); created++; }
        catch (e) { failures.push(`${o.method} ${o.path}: ${e.message}`); }
        tick();
      }
    };
    await Promise.all(Array.from({ length: 4 }, worker));

    // 4. deactivate removed
    let deactivated = 0;
    for (const id of deactIds) {
      const e = eps.find(x => x.id === id) || existing.find(x => x.id === id);
      try {
        await api.update("apiaudit", id, { ...e, isActive: false, modifiedDate: new Date().toISOString(),
          notes: [e.notes, "Removed from Swagger " + new Date().toLocaleDateString()].filter(Boolean).join(" · ") });
        deactivated++;
      } catch (e2) { failures.push(`Deactivate #${id}: ${e2.message}`); }
      tick();
    }
    if (created || deactivated || linked) setChanged(true);
    setProgress(100);
    setResult({ created, deactivated, linked, skipped, failures, filled: [...filled], host: th });
  }

  const title = host ? `Sync "${host.apiHostName || host.apiHostUrl}" from Swagger` : "Add API from Swagger";
  const close = () => done(changed || null);
  const nAuth = parsed ? parsed.endpoints.filter(o => o.auth).length : 0;
  const nNew = parsed ? parsed.endpoints.filter(o => !o.exists).length : 0;
  const hd = Object.keys(hostDefaults(targetHost)).length, nd = Object.keys(baseDetails).length;

  return (
    <>
      <Modal.Header><Modal.Title as="h5">{title}</Modal.Title><button type="button" className="btn-close" aria-label="Close" onClick={close} /></Modal.Header>
      <Modal.Body>
        {step === 1 && <div>
          <p className="text-muted small mb-3">Enter the API's address and its Swagger login. CockyAuditor downloads <code>swagger.json</code> and lists every endpoint so you can import them for auditing.</p>
          <div className="row g-3">
            <div className="col-md-7"><Form.Label className="small mb-1" htmlFor="sw_root">API URL</Form.Label>
              <Form.Control id="sw_root" placeholder="https://myapi.azurewebsites.net" autoComplete="url" value={root} readOnly={!!host} onChange={e => setRoot(e.target.value)} autoFocus={!host} /></div>
            <div className="col-md-5"><Form.Label className="small mb-1" htmlFor="sw_name">Name <span className="text-muted">(optional)</span></Form.Label>
              <Form.Control id="sw_name" placeholder="Taken from Swagger if blank" value={name} onChange={e => setName(e.target.value)} /></div>
            <div className="col-md-4"><Form.Label className="small mb-1" htmlFor="sw_user">Swagger username</Form.Label>
              <Form.Control id="sw_user" autoComplete="off" value={user} onChange={e => setUser(e.target.value)} autoFocus={!!host} /></div>
            <div className="col-md-4"><Form.Label className="small mb-1" htmlFor="sw_pass">Swagger password</Form.Label>
              <InputGroup><Form.Control id="sw_pass" type={showPass ? "text" : "password"} autoComplete="new-password" value={pass} onChange={e => setPass(e.target.value)} />
                <Button variant="outline-secondary" onClick={() => setShowPass(s => !s)}>{showPass ? "Hide" : "Show"}</Button></InputGroup></div>
            <div className="col-md-4"><Form.Label className="small mb-1" htmlFor="sw_path">swagger.json path</Form.Label>
              <Form.Control id="sw_path" value={specPath} onChange={e => setSpecPath(e.target.value)} />
              <div className="form-text">Other common locations are tried automatically.</div></div>
            <div className="col-12"><Form.Check id="sw_save" className="small" checked={saveLogin} onChange={e => setSaveLogin(e.target.checked)}
              label="Save the Swagger login on the host, so re-syncing doesn't ask again" /></div>
          </div>
          <details className="mt-3"><summary className="small">Can't reach it? Paste or upload swagger.json instead</summary>
            <div className="mt-2">
              <Form.Control type="file" size="sm" className="mb-2" accept=".json,application/json" onChange={async e => { const f = e.target.files[0]; if (f) setPaste(await f.text()); }} />
              <Form.Control as="textarea" className="font-monospace small" rows={5} placeholder='{"openapi":"3.0.1", ...}' value={paste} onChange={e => setPaste(e.target.value)} />
              <div className="form-text">Still fill in the API URL above; it's used as the address for the endpoints.</div>
            </div>
          </details>
          <div className="mt-3 small text-muted">{log}</div>
          {err && <Alert variant="danger" className="small mt-2">{err}</Alert>}
        </div>}

        {step === 2 && parsed && <div>
          <div className="mb-2" id="sw_summary">
            <div className="d-flex flex-wrap gap-3 align-items-baseline">
              <h6 className="mb-0">{parsed.title || "API"} <span className="text-muted fw-normal">{parsed.version}</span></h6>
              <span className="small text-muted">{parsed.specVersion ? "OpenAPI " + parsed.specVersion : ""} · {parsed.rootUrl}</span>
            </div>
            <div className="small mt-1">{parsed.endpoints.length} operations · <b>{nNew} new</b> · {parsed.endpoints.length - nNew} already registered
              {rec.adopt.length ? ` (${rec.adopt.length} will be linked to this host)` : ""} ·{" "}
              {nAuth ? `${nAuth} declare authentication` : <span className="text-warning-emphasis">none declare authentication in Swagger</span>}
              {targetHost ? <> · host <b>#{targetHost.id} {targetHost.apiHostName || ""}</b></> : " · a new host will be created"}</div>
          </div>
          <div className="d-flex flex-wrap gap-2 align-items-center mb-2">
            <Form.Control size="sm" style={{ maxWidth: 260 }} placeholder="Filter by path, method or tag…" value={filter} onChange={e => setFilter(e.target.value)} />
            <Form.Check id="sw_all" className="ms-1 small" label="Select all shown" checked={allShownPicked}
              onChange={e => setPicks(s => { const n = new Set(s); shown.filter(o => !o.exists).forEach(o => e.target.checked ? n.add(o.key) : n.delete(o.key)); return n; })} />
            <span className="ms-auto small text-muted">{nPicked} selected</span>
          </div>
          <div className="table-responsive" style={{ maxHeight: "48vh" }}><table className="table table-sm align-middle mb-0">
            <thead className="sticky-top bg-white"><tr><th></th><th>Method</th><th>Path</th><th>Tag</th><th>Summary</th><th>Auth</th><th>Status</th></tr></thead>
            <tbody>
              {shown.length ? shown.map(o => (
                <tr key={o.key + o.path} className={o.exists ? "text-muted" : ""}>
                  <td><Form.Check className="sw-pick" checked={picks.has(o.key) && !o.exists} disabled={o.exists} onChange={e => togglePick(o.key, e.target.checked)} /></td>
                  <td><MethodBadge method={o.method} /></td><td className="font-monospace small">{o.path}</td>
                  <td className="small">{o.tag}</td><td className="small">{String(o.summary).slice(0, 80)}</td>
                  <td className="small">{o.auth ? <span className="badge text-bg-success" title={o.authType}>Required</span> : <span className="badge text-bg-light border">None</span>}</td>
                  <td className="small">{o.exists ? <>Registered <span className="text-muted">#{o.existing.id}</span></> : <span className="text-success">New</span>}
                    {o.deprecated && <span className="badge text-bg-secondary ms-1">deprecated</span>}</td>
                </tr>)) : <tr><td colSpan={7} className="text-center text-muted py-3">Nothing matches.</td></tr>}
            </tbody></table></div>
          {rec.notInSwagger.length > 0 && <Alert variant="warning" className="small mb-0 mt-3">
            <Form.Check id="sw_deact" checked={deact} onChange={e => setDeact(e.target.checked)}
              label={<><b>{rec.notInSwagger.length}</b> registered endpoint(s) for this host are no longer in Swagger. Mark them inactive:</>} />
            <div className="mt-1">{rec.notInSwagger.slice(0, 12).map(e => e.description || e.url).join(" · ")}{rec.notInSwagger.length > 12 ? " …" : ""}</div>
          </Alert>}
          {rec.dupes.length > 0 && <Alert variant="info" className="small mb-0 mt-2">{dupeNote(rec.dupes)}</Alert>}
          <div className="card mt-3"><div className="card-body py-3">
            <div className="d-flex flex-wrap gap-2 align-items-center">
              <b className="small">Endpoint details</b>
              <span className="small text-muted">Swagger has no contacts, database, business unit or Azure info. Copy them from an endpoint you've already filled in:</span>
              <Form.Select size="sm" style={{ maxWidth: 340 }} value={tplId} onChange={e => { setTplId(e.target.value); setEdits({}); }}>
                <option value="">Don't copy (leave details blank)</option>
                {candidates.map(e => <option key={e.id} value={e.id}>#{e.id} {e.description || e.url || ""}{e.apiHostId === targetHost?.id ? " (this API)" : ""} · {richness(e)} fields</option>)}
              </Form.Select>
            </div>
            <div className="small text-muted mt-2">{nd
              ? `${nd} fields will be copied to each new endpoint${hd ? ` (${hd} from the host's defaults${tpl ? ", the rest from the endpoint" : ""})` : ""}. Swagger values (method, path, tag, auth) always win.`
              : "Imported endpoints will only have what Swagger provides. Fill in the host's defaults (Hosts → Details) or pick an endpoint to copy from."}</div>
            <details className="mt-2"><summary className="small">Review / edit the details applied to every imported endpoint</summary>
              <div className="row g-2 mt-1">{DETAIL_FIELDS.map(k => (
                <div key={k} className="col-md-4 col-lg-3">
                  <Form.Label className="small mb-0 text-muted" htmlFor={"swd_" + k}>{titleCase(k)}</Form.Label>
                  <Form.Control size="sm" id={"swd_" + k} value={k in edits ? edits[k] : (baseDetails[k] ?? "")} onChange={e => setEdits(s => ({ ...s, [k]: e.target.value }))} />
                </div>))}</div>
            </details>
            <Form.Check id="sw_savehost" className="mt-2 small" checked={saveHost} onChange={e => setSaveHost(e.target.checked)} label="Save these details on the host as its defaults (fills blanks only)" />
          </div></div>
          {err && <Alert variant="danger" className="small mt-2 mb-0">{err}</Alert>}
        </div>}

        {step === 3 && <div>
          <ProgressBar now={progress} className="mb-3" />
          <div id="sw_result">
            {!result ? <Spinner text={status} /> : result.fatal ? <Alert variant="danger">{result.fatal}</Alert> : <>
              <Alert variant={result.failures.length ? "warning" : "success"}>
                <b>{result.created}</b> new endpoint(s) imported{result.deactivated ? <>, <b>{result.deactivated}</b> marked inactive</> : ""} for host <b>#{result.host.id} {result.host.apiHostName || ""}</b>.
                {result.skipped > 0 && <div className="small mt-1">{result.skipped} selected operation(s) were already registered by the time of import and were skipped.</div>}
                {result.linked > 0 && <div className="small mt-1">{result.linked} existing endpoint(s) linked to this host instead of being added again.</div>}
                {result.failures.length > 0 && <><div className="mt-1"><b>{result.failures.length}</b> failed:</div><ul className="small mb-0">{result.failures.slice(0, 20).map((f, i) => <li key={i}>{f}</li>)}</ul></>}
                {result.filled.length > 0 && <div className="small mt-2">The API required these fields, so they were filled with "N/A" or 0: {result.filled.join(", ")}. Consider making them nullable.</div>}
              </Alert>
              <Link className="btn btn-primary" to={`/audit?host=${result.host.id}`} onClick={() => done(true)}>Audit this API now</Link>
              <Link className="btn btn-outline-secondary ms-2" to="/endpoints" onClick={() => done(true)}>View endpoints</Link>
            </>}
          </div>
        </div>}
      </Modal.Body>
      <Modal.Footer>
        {step === 2 && <Button variant="outline-secondary" className="me-auto" onClick={() => { setErr(null); setStep(1); }}>Back</Button>}
        <Button variant="secondary" onClick={close}>{step === 3 ? "Close" : "Cancel"}</Button>
        {step === 1 && <Button id="sw_next" onClick={doFetch} disabled={busy}>{busy ? "Fetching…" : "Fetch endpoints"}</Button>}
        {step === 2 && <Button id="sw_next" onClick={doImport}>Import {nPicked} endpoint{nPicked === 1 ? "" : "s"}</Button>}
      </Modal.Footer>
    </>
  );
}
