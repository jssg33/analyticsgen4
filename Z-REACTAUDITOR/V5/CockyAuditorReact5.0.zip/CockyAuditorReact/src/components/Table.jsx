// Table for any resource, and the full list page (search, refresh, add, edit, delete) used by
// Apps / Hosts / Endpoints / Exceptions / History. Ports of renderTable and crudPage in app.js.
import { forwardRef, useCallback, useEffect, useImperativeHandle, useRef, useState } from "react";
import { Button, Form } from "react-bootstrap";
import SCHEMA from "../schema.js";
import api, { ensureRefs } from "../lib/api.js";
import { fieldType, filterRows, titleCase } from "../lib/util.js";
import { useDialogs } from "./Dialogs.jsx";
import { useToast } from "./Toasts.jsx";
import { Empty, ErrorBox, FmtValue, Spinner } from "./ui.jsx";

function columnsOf(resource, rows) {
  const preferred = SCHEMA[resource]?.columns || [];
  if (!rows.length) return preferred;
  const keys = new Set(rows.flatMap(r => Object.keys(r)));
  const cols = preferred.filter(c => keys.has(c));
  if (cols.length >= 3) return cols;
  return [...keys].slice(0, 8);
}

// render: { column: (value, row) => node } for computed or custom columns
// rowActions: [{ label: string | row => node, className, title: string | row => string, onClick(row) }]
export function DataTable({ resource, rows, columns, render = {}, onRowClick, rowActions, onEdit, onDelete, emptyText, className = "" }) {
  const cols = columns || columnsOf(resource, rows);
  if (!rows.length) return <Empty>{emptyText || `No ${(SCHEMA[resource]?.labelPlural || resource).toLowerCase()} yet.`}</Empty>;
  const actions = onEdit || onDelete || rowActions;
  const stop = fn => e => { e.stopPropagation(); fn(); };
  return (
    <div className="table-responsive"><table className={`table table-hover table-sm align-middle mb-0 ${className}`}>
      <thead><tr>{cols.map(c => <th key={c}>{SCHEMA[resource]?.titles?.[c] || titleCase(c)}</th>)}{actions && <th></th>}</tr></thead>
      <tbody>{rows.map((r, i) => (
        <tr key={r.id ?? i} className={onRowClick ? "clickable" : ""} onClick={onRowClick ? () => onRowClick(r) : undefined}>
          {cols.map(c => <td key={c}>{render[c] ? render[c](r[c], r) : <FmtValue v={r[c]} type={fieldType(resource, c, r[c])} />}</td>)}
          {actions && <td className="text-end text-nowrap">
            {(rowActions || []).map((a, ai) => (
              <Button key={ai} size="sm" variant={a.variant || "outline-primary"} className={`me-1 ${a.className || ""}`}
                title={typeof a.title === "function" ? a.title(r) : a.title} onClick={stop(() => a.onClick(r))}>
                {typeof a.label === "function" ? a.label(r) : a.label}
              </Button>))}
            {onEdit && <Button size="sm" variant="outline-secondary" className="me-1" onClick={stop(() => onEdit(r))}>Edit</Button>}
            {onDelete && <Button size="sm" variant="outline-danger" onClick={stop(() => onDelete(r))}>Delete</Button>}
          </td>}
        </tr>))}
      </tbody>
    </table></div>
  );
}

// source(): list suffix to load (e.g. "/active"). sort(rows): filter/sort after loading.
// beforeLoad(): async hook run with every load (e.g. reload lookup data). onCreated(record) after "+ Add" saves.
// beforeDelete(record): runs after the delete is confirmed; may return an undo function, called if the delete fails.
// reloadKey: change it to reload (e.g. when a filter changes). Ref: { reload(), rows() }.
export const CrudPage = forwardRef(function CrudPage(
  { resource, toolbarExtra, source = () => "", sort, columns, render, rowActions, beforeLoad, onCreated, beforeDelete, onLoaded, reloadKey, addLabel, noAdd, noEdit }, ref) {
  const sch = SCHEMA[resource];
  const dialogs = useDialogs(), toast = useToast();
  const [rows, setRows] = useState(null);
  const [error, setError] = useState(null);
  const [q, setQ] = useState("");
  const rowsRef = useRef([]);
  const opts = useRef({}); opts.current = { source, sort, beforeLoad, onLoaded };

  const load = useCallback(async () => {
    setRows(null); setError(null);
    try {
      const o = opts.current;
      const [list] = await Promise.all([api.list(resource, o.source()), ensureRefs(resource), o.beforeLoad?.()]);
      const r = o.sort ? o.sort(list) : list;
      rowsRef.current = r; setRows(r); o.onLoaded?.(r);
    } catch (e) { setError(e); }
  }, [resource]);
  useEffect(() => { load(); }, [load, reloadKey]);
  useImperativeHandle(ref, () => ({ reload: load, rows: () => rowsRef.current }), [load]);

  async function remove(row) {
    const name = row.applicationName || row.description || row.apiHostName || row.hostName || row.name || "";
    const ok = await dialogs.confirm({ title: `Delete ${sch.label || "record"}?`, okText: "Delete", variant: "danger",
      body: <>Delete {sch.label || "record"} #{row.id}{name ? ` (${name})` : ""}? This can't be undone.</> });
    if (!ok) return;
    let undo = null;
    try {
      undo = await beforeDelete?.(row);
      await api.remove(resource, row.id);
      toast(`${sch.label || "Record"} #${row.id} deleted.`);
      load();
    } catch (e) {
      if (typeof undo === "function") { try { await undo(); } catch (u) { e.message += ` (and restoring the removed links failed: ${u.message})`; } }
      toast(e.message, "danger");
    }
  }
  async function add() {
    const saved = await dialogs.recordForm(resource, null, rowsRef.current);
    if (!saved) return;
    await load();
    onCreated?.(saved);
  }

  const shown = rows ? filterRows(rows, q) : [];
  return (
    <div className="card"><div className="card-body">
      <div className="d-flex flex-wrap gap-2 mb-3 align-items-center">
        <Form.Control size="sm" style={{ maxWidth: 260 }} placeholder="Search…" value={q} onChange={e => setQ(e.target.value)} />
        {toolbarExtra}
        <span className="text-muted small ms-1">{rows?.length ? `${shown.length} of ${rows.length}` : ""}</span>
        <div className="ms-auto d-flex gap-2">
          <Button size="sm" variant="outline-secondary" onClick={load}>Refresh</Button>
          {!noAdd && <Button size="sm" onClick={add}>+ {addLabel || `Add ${sch.label}`}</Button>}
        </div>
      </div>
      {error ? <ErrorBox error={error} onRetry={load} />
        : !rows ? <Spinner />
        : <DataTable resource={resource} rows={shown} columns={columns} render={render} rowActions={rowActions}
            emptyText={rows.length ? "Nothing matches your search." : `No ${sch.labelPlural.toLowerCase()} yet.${noAdd ? "" : ` Use "+ Add ${sch.label}" to create one.`}`}
            onEdit={noEdit ? undefined : async r => { if (await dialogs.recordForm(resource, r, rowsRef.current)) load(); }}
            onDelete={remove} />}
    </div></div>
  );
});
