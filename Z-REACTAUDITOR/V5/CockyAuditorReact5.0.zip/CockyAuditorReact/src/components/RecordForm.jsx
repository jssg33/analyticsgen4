// Add / edit dialog for any resource (port of openRecordForm in app.js).
// sampleRows: existing records, used to learn field names. defaults: starting values for a new record.
// opts.view: "core" (groups without detail:true), "details" (only detail groups) or "all". Fields not shown are
// kept unchanged from the record when saving.
import { useEffect, useMemo, useState } from "react";
import { Alert, Button, Form, InputGroup, Modal, Nav } from "react-bootstrap";
import SCHEMA from "../schema.js";
import api, { ensureRefs, refRows } from "../lib/api.js";
import { fieldType, parseDate, refLabel, refTarget, titleCase } from "../lib/util.js";
import { useToast } from "./Toasts.jsx";
import { Spinner } from "./ui.jsx";

function toLocalInput(v) {
  if (!v) return "";
  const d = parseDate(v);
  if (!d) return "";
  const p = n => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}
// value -> what the input shows
function toInput(type, v) {
  if (type === "bool") return !!v;
  if (type === "date") return toLocalInput(v);
  return v ?? "";
}
// what the input shows -> value sent to the API
function fromInput(type, v) {
  if (type === "bool") return !!v;
  if (type === "number" || refTarget(type)) return v === "" || v == null ? null : Number(v);
  if (type === "date") return v ? new Date(v).toISOString() : null;
  return v === "" ? null : v;
}

export default function RecordForm({ resource, record, sampleRows, defaults, opts, done }) {
  const toast = useToast();
  const [ready, setReady] = useState(false);
  useEffect(() => { ensureRefs(resource).then(() => setReady(true)); }, [resource]);

  const isNew = !record;
  const sch = SCHEMA[resource] || { fields: {} };

  // Which fields to show, grouped like the HTML version
  const setup = useMemo(() => {
    const learned = sampleRows.length ? Object.keys(Object.assign({}, ...sampleRows)) : [];
    let keys = [...new Set(record ? Object.keys(record) : learned.length ? learned : Object.keys(sch.fields))];
    const view = opts.view || sch.defaultView || "all";
    let schGroups = sch.groups;
    if (schGroups && view !== "all") {
      const detailKeys = new Set(schGroups.filter(g => g.detail).flatMap(g => g.keys));
      schGroups = schGroups.filter(g => view === "details" ? g.detail : !g.detail);
      keys = keys.filter(k => view === "details" ? detailKeys.has(k) : !detailKeys.has(k));
    }
    const sample = record || Object.assign({}, ...sampleRows);
    const base = {};
    if (isNew) keys.forEach(k => { if (k !== "id") base[k] = fieldType(resource, k, sample[k]) === "bool" ? /^(is)?active$/i.test(k) : null; });
    if (isNew) Object.entries(defaults).forEach(([k, v]) => { base[k] = v; if (!keys.includes(k)) keys.push(k); });
    const shownKeys = keys.filter(k => !(k === "id" && isNew));
    const types = Object.fromEntries(shownKeys.map(k => [k, fieldType(resource, k, sample[k])]));
    let groups = null;
    if (schGroups) {
      const placed = new Set(sch.groups.flatMap(g => g.keys));
      groups = schGroups.map(g => ({ ...g, keys: g.keys.filter(k => shownKeys.includes(k)) }))
        .concat([{ title: "Other", keys: shownKeys.filter(k => !placed.has(k)) }]).filter(g => g.keys.length);
    }
    const title = view === "details" && record
      ? `${sch.label || resource} details: ${record.apiHostName || record.description || "#" + record.id}`
      : `${isNew ? "Add" : "Edit"} ${sch.label || resource}${record ? " #" + record.id : ""}`;
    const guessing = !sch.verified && !learned.length && !record;
    return { shownKeys, types, groups, base, title, guessing };
  }, [resource, record, sampleRows, defaults, opts, isNew, sch]);

  const start = record || setup.base;
  const [inputs, setInputs] = useState(() => Object.fromEntries(setup.shownKeys.map(k => [k, toInput(setup.types[k], start[k])])));
  const [tab, setTab] = useState("form");
  const [json, setJson] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [shown, setShown] = useState({});   // password fields shown as text

  const readForm = () => {
    const out = { ...start };
    setup.shownKeys.forEach(k => { out[k] = fromInput(setup.types[k], inputs[k]); });
    return out;
  };
  const switchTab = t => {
    if (t === tab) return;
    try {
      if (t === "json") setJson(JSON.stringify(readForm(), null, 2));
      else {
        const obj = JSON.parse(json);
        setInputs(Object.fromEntries(setup.shownKeys.map(k => [k, toInput(setup.types[k], obj[k])])));
      }
    } catch (e) { setError("JSON is not valid: " + e.message); return; }
    setError(""); setTab(t);
  };

  async function save() {
    let body;
    try { body = tab === "form" ? readForm() : JSON.parse(json); } catch (e) { setError("JSON is not valid: " + e.message); return; }
    if (!isNew) body.id = record.id;
    if (isNew) { const now = new Date().toISOString(); ["createdDate", "modifiedDate"].forEach(k => { if (k in body && !body[k]) body[k] = now; }); }
    else if ("modifiedDate" in body) body.modifiedDate = new Date().toISOString();
    setSaving(true); setError("");
    try {
      let saved, filled = [];
      if (isNew) ({ data: saved, filled } = await api.createFilling(resource, body));
      else saved = await api.update(resource, record.id, body);
      toast(`${sch.label || "Record"} ${isNew ? "added" : "saved"}.` +
        (filled.length ? ` The API required ${filled.length} blank field(s), filled with N/A/0: ${filled.join(", ")}.` : ""),
        filled.length ? "warning" : "success");
      done(saved ?? body);
    } catch (e) { setError(e.message); setSaving(false); }
  }

  const set = (k, v) => setInputs(s => ({ ...s, [k]: v }));
  const field = k => {
    const type = setup.types[k], id = "f_" + k, v = inputs[k];
    const label = <Form.Label className="small mb-1" htmlFor={id}>{titleCase(k)}</Form.Label>;
    if (type === "bool") return (
      <div key={k} className="col-md-4 d-flex align-items-end">
        <Form.Check id={id} data-key={k} label={titleCase(k)} checked={!!v} onChange={e => set(k, e.target.checked)} />
      </div>);
    if (type === "number") return (
      <div key={k} className="col-md-4">{label}<Form.Control size="sm" type="number" id={id} data-key={k} value={v} readOnly={k === "id"} onChange={e => set(k, e.target.value)} /></div>);
    if (type === "date") return (
      <div key={k} className="col-md-4">{label}<Form.Control size="sm" type="datetime-local" id={id} data-key={k} value={v} onChange={e => set(k, e.target.value)} /></div>);
    if (type === "password") return (
      <div key={k} className="col-md-6">{label}<InputGroup size="sm">
        <Form.Control type={shown[k] ? "text" : "password"} autoComplete="new-password" id={id} data-key={k} value={v} onChange={e => set(k, e.target.value)} />
        <Button variant="outline-secondary" onClick={() => setShown(s => ({ ...s, [k]: !s[k] }))}>{shown[k] ? "Hide" : "Show"}</Button>
      </InputGroup></div>);
    const ref = refTarget(type);
    if (ref) {
      const rows = refRows(ref), known = rows.some(r => String(r.id) === String(v));
      return (
        <div key={k} className="col-md-6">{label}
          <Form.Select size="sm" id={id} data-key={k} value={v ?? ""} onChange={e => set(k, e.target.value)}>
            <option value="">(none)</option>
            {rows.map(r => <option key={r.id} value={r.id}>{refLabel(r)}</option>)}
            {v !== "" && v != null && !known && <option value={v}>#{v} (not found)</option>}
          </Form.Select></div>);
    }
    if (type === "text") return (
      <div key={k} className="col-12">{label}<Form.Control as="textarea" rows={2} size="sm" id={id} data-key={k} value={v} onChange={e => set(k, e.target.value)} /></div>);
    return (
      <div key={k} className="col-md-6">{label}<Form.Control size="sm" type="text" id={id} data-key={k} value={v} readOnly={k === "id"} onChange={e => set(k, e.target.value)} /></div>);
  };
  const filledGroup = g => record && g.keys.some(k => k !== "id" && record[k] !== null && record[k] !== "" && record[k] !== false && record[k] !== 0 && record[k] !== "string");

  return (
    <>
      <Modal.Header closeButton><Modal.Title as="h5">{setup.title}</Modal.Title></Modal.Header>
      <Modal.Body>
        {!ready ? <Spinner /> : <>
          {setup.guessing && <Alert variant="warning" className="small">
            There are no {(sch.labelPlural || resource).toLowerCase()} yet, so these fields are a best guess. Compare with the Swagger schema; if the save fails, adjust in the JSON tab (and in schema.js).</Alert>}
          <Nav variant="tabs" className="mb-3" activeKey={tab} onSelect={switchTab}>
            <Nav.Item><Nav.Link eventKey="form">Form</Nav.Link></Nav.Item>
            <Nav.Item><Nav.Link eventKey="json">JSON</Nav.Link></Nav.Item>
          </Nav>
          {tab === "form" ? (
            <form className="row g-3" onSubmit={e => { e.preventDefault(); save(); }}>
              {setup.groups
                ? setup.groups.map((g, i) => (
                  <details key={g.title} className="col-12 form-section" open={i === 0 || filledGroup(g) || undefined}>
                    <summary>{g.title} <span className="text-muted small fw-normal">({g.keys.length})</span></summary>
                    <div className="row g-3 pt-2">{g.keys.map(field)}</div>
                  </details>))
                : setup.shownKeys.map(field)}
            </form>
          ) : (
            <div>
              <Form.Control as="textarea" className="font-monospace" rows={18} spellCheck={false} value={json} onChange={e => setJson(e.target.value)} />
              <div className="form-text">Edit the exact JSON that will be sent. Useful if the API expects fields the form doesn't show.</div>
            </div>
          )}
          {error && <Alert variant="danger" className="small mt-3 mb-0">{error}</Alert>}
        </>}
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={() => done(null)}>Cancel</Button>
        <Button onClick={save} disabled={saving || !ready} className="save-btn">{saving ? "Saving…" : "Save"}</Button>
      </Modal.Footer>
    </>
  );
}
