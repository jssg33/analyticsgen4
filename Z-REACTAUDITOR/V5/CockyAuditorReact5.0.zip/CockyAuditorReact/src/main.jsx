import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { HashRouter, Navigate, Route, Routes } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./styles.css";
import { ToastProvider } from "./components/Toasts.jsx";
import { DialogProvider } from "./components/Dialogs.jsx";
import Layout, { RequireAuth } from "./components/Layout.jsx";
import Login from "./pages/Login.jsx";
import Welcome from "./pages/Welcome.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Apps from "./pages/Apps.jsx";
import Hosts from "./pages/Hosts.jsx";
import Endpoints from "./pages/Endpoints.jsx";
import RunAudit from "./pages/RunAudit.jsx";
import Exceptions from "./pages/Exceptions.jsx";
import History from "./pages/History.jsx";
import Enterprise9 from "./pages/Enterprise9.jsx";

// HashRouter (#/hosts): works on any static host without server rewrite rules
createRoot(document.getElementById("root")).render(
  <StrictMode>
    <HashRouter>
      <ToastProvider>
        <DialogProvider>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/" element={<RequireAuth><Welcome /></RequireAuth>} />
            <Route element={<RequireAuth><Layout /></RequireAuth>}>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/apps" element={<Apps />} />
              <Route path="/hosts" element={<Hosts />} />
              <Route path="/endpoints" element={<Endpoints />} />
              <Route path="/audit" element={<RunAudit />} />
              <Route path="/exceptions" element={<Exceptions />} />
              <Route path="/history" element={<History />} />
              <Route path="/enterprise9" element={<Enterprise9 />} />
            </Route>
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </DialogProvider>
      </ToastProvider>
    </HashRouter>
  </StrictMode>
);
