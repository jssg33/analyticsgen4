# CockyAuditor (React)

CockyAuditor Build 4.6 rebuilt in React: the same pages, audit API, login, and rules, with the Enterprise(9) logs.
**Build 5.0 · React.**

## The compiled site: `www/`
`www/` is the ready-to-deploy site. Copy the whole folder to any static web host (Azure Static Web Apps, App Service,
IIS, nginx...) and open `index.html`. No server-side code or URL rewrite rules are needed: pages use hash URLs
(`…/index.html#/hosts`), and all paths are relative, so it also works from a sub-folder.

It needs a web server; opening `www/index.html` straight from disk won't run, because browsers block module scripts
on `file://`. For a quick local look: `npx vite preview` (after a build) or `python -m http.server` inside `www/`.

The audit API (and each application's API, for Enterprise(9) logs) must allow the site's origin in CORS, as before.

## Building
Requires Node.js 20.19 or later.

```
npm install
npm run dev      # development server with live reload at http://localhost:5173
npm run build    # compiles into www/
```

## Settings
- `src/config.js`: API base URL and routes, timeouts, copyright, build history, and the Enterprise(9) log sets
  (`enterpriseLogs.types`, `take`, `exclude`). Same settings as `config.js` in the HTML version.
- `src/schema.js`: field lists and types for each resource, plus the audit summary that Run Audit saves.

Changes to either take effect on the next `npm run build`.

## Sign in
Test login **audit / audit**. It uses the same localStorage keys and rules as the HTML version, so both builds agree:
`userid` `10000` / `role` `auditor` / `username` `auditor` / `email` `auditor@capitoltechnology.net` when signed in,
and `userid` `901` when signed out. Every page requires role `auditor` and a `userid` other than `901`; otherwise it
goes to the login page and returns you to the page you asked for afterwards.
The check is client-side only (see `src/lib/auth.js`). Replace it with the API's real login before this is public.

## Pages (routes)
| Page | Route |
|---|---|
| Sign in | `#/login` |
| Welcome | `#/` |
| Dashboard | `#/dashboard` |
| Apps | `#/apps` (Link hosts, Endpoints, Enterprise(9)) |
| Hosts | `#/hosts` (Audit host, Sync Swagger, Details, Push details, Except host; `?add=1` opens Add API from Swagger) |
| Endpoints | `#/endpoints` (`?app=<id>` or `?host=<id>`) |
| Run Audit | `#/audit` (`?host=<id>`, `?id=<endpoint>`, `?host=<id>&walk=1` walks Swagger and audits the host) |
| Exceptions | `#/exceptions` (`?tab=hosts`, `?audit=<endpoint>`, `?host=<id>` starts a host exception) |
| History | `#/history` |
| Enterprise(9) | `#/enterprise9` (`?app=<id>`, `?log=<set>`) |

## Code layout
- `src/lib/`: logic with no UI, ported unchanged from the HTML version
  - `api.js`: API client (including the required-field retry)
  - `auth.js`: sign-in
  - `swagger.js`: swagger.json fetch/parse, matching operations to existing endpoints so none are registered twice,
    Audit host's walk, and host defaults
  - `audit.js`: target URLs, exception matching, the per-endpoint checks (GET only)
  - `e9.js`: Enterprise(9) log discovery (any endpoint with "log" in its path, plus the standard sets)
  - `util.js`: dates, app roll-ups, and small helpers
- `src/components/`: layout and route guard, toasts, dialogs (confirm, add/edit record, Swagger login,
  "Add new endpoints?"), the Swagger wizard, and the table/list page shared by Apps, Hosts, Endpoints, Exceptions and History
- `src/pages/`: one file per page

## Behavior
Everything in the HTML version's README applies unchanged. That covers:
- how existing endpoints are recognized, the confirm-before-insert prompt, host defaults, and the required-field retry
- how Run Audit builds URLs and checks endpoints, exceptions and host exceptions, and what a saved audit contains
- dates, Apps, and Enterprise(9)
