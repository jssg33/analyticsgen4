import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// base "./" so the built site works from any folder on any static host
export default defineConfig({
  plugins: [react()],
  base: "./",
  // "npm run build" writes the compiled site to www/ (copy that folder to any static web host)
  build: { outDir: "www", emptyOutDir: true },
  server: { port: 5173 }
});
