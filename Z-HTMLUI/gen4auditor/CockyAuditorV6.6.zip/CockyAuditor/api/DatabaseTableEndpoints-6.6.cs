// Build 6.6: DatabaseTable endpoints for the Schema Area editor (Database Tables page) and Report 02.
// Add these to the MVC that already serves GET /api/databasetables on each host API (merge into that controller, or map
// this one instead). CockyAuditor needs:
//   GET  /api/databasetables          - the list (already there)
//   GET  /api/databasetables/{id}     - one table; the page reads it back after saving to confirm SchemaArea was kept
//   PUT  /api/databasetables/{id}     - the page sends the whole record; ONLY SchemaArea is taken from it, so a stale
//                                       copy in the browser can never roll back what discovery measured
// Assumes the entity is DatabaseTable (Id, TableName, SchemaName, ModelName, ColumnCount, LastAuditDate, IsActive,
// SchemaArea) in EnterpriseContext as DbSet<DatabaseTable> DatabaseTables. Rename to match your project.
// CORS: the host's policy must allow CockyAuditor's origin with the PUT method and the Content-Type / Authorization headers.
using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Enterprise.Models;

namespace somecontrollers.Controllers;

[ApiController]
[Route("api/databasetables")]
// [Authorize]   // turn on once this host validates CockyAuditor's Bearer token (Run Audit's token check will then pass)
public class DatabaseTablesController : ControllerBase
{
    private const int SchemaAreaMax = 100;
    private readonly EnterpriseContext _db;
    public DatabaseTablesController(EnterpriseContext db) => _db = db;

    [HttpGet]
    public async Task<IActionResult> GetAll() =>
        Ok(await _db.DatabaseTables.AsNoTracking().OrderBy(t => t.SchemaName).ThenBy(t => t.TableName).ToListAsync());

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetOne(int id)
    {
        var t = await _db.DatabaseTables.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        return t is null ? NotFound() : Ok(t);
    }

    public sealed class SchemaAreaBody
    {
        public int? Id { get; set; }
        public string? SchemaArea { get; set; }
    }

    // Body: the whole DatabaseTable record (or just { "schemaArea": "..." }). Blank clears the area.
    [HttpPut("{id:int}")]
    public async Task<IActionResult> PutSchemaArea(int id, [FromBody] SchemaAreaBody body)
    {
        if (body is null) return BadRequest("Body required.");
        if (body.Id.HasValue && body.Id.Value != id) return BadRequest("Id in the body doesn't match the route.");
        var area = string.IsNullOrWhiteSpace(body.SchemaArea) ? null : body.SchemaArea.Trim();
        if (area is { Length: > SchemaAreaMax }) return BadRequest($"SchemaArea is limited to {SchemaAreaMax} characters.");

        var t = await _db.DatabaseTables.FirstOrDefaultAsync(x => x.Id == id);
        if (t is null) return NotFound();
        t.SchemaArea = area;
        await _db.SaveChangesAsync();
        return Ok(t);
    }
}

// Discovery (SqlAzureTableAudit.RunAudit): when it refreshes a table it already has, copy only the measured values onto the
// existing row and leave SchemaArea alone, otherwise every discovery run wipes the areas set on the Database Tables page.
