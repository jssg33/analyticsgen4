using Enterprise.Models;
using Microsoft.EntityFrameworkCore;

namespace Enterprise.Controllers;

public static class ApiServiceEndpointsController
{
    // NOTE: DbSet names below must match your EnterpriseContext:
    //   context.ApiServices            (exists)
    //   context.ApiServiceEndpoints    (add: DbSet<ApiServiceEndpoint>)
    //   context.Apiaudit               (the endpoint table — rename here if yours differs, e.g. Apiaudits)

    public static void MapApiServiceEndpointsEndpoints(RouteGroupBuilder group)
    {
        // ---- READ: endpoints linked to a service (Services -> ApiAudit Details) ----
        group.MapGet("/by-service/{serviceId:int}", async (int serviceId) =>
        {
            using var context = new EnterpriseContext();

            var rows = await (
                from link in context.ApiServiceEndpoints.Where(l => l.ServiceId == serviceId)
                join ep in context.Apiaudit on link.ApiAuditId equals ep.Id
                orderby ep.Url
                select new
                {
                    LinkId        = link.Id,
                    link.ServiceId,
                    link.ApiAuditId,
                    ep.ApiHostId,
                    ep.Url,
                    ep.EndpointType,
                    ep.Family,
                    ep.ApplicationName,
                    ep.Environment
                }).ToListAsync();

            return Results.Ok(rows);
        })
        .WithName("GetEndpointsForService")
        .WithOpenApi();

        // ---- READ: services linked to an endpoint ----
        group.MapGet("/by-endpoint/{apiAuditId:int}", async (int apiAuditId) =>
        {
            using var context = new EnterpriseContext();

            var rows = await (
                from link in context.ApiServiceEndpoints.Where(l => l.ApiAuditId == apiAuditId)
                join svc in context.ApiServices on link.ServiceId equals svc.Id
                orderby svc.ServiceName
                select new
                {
                    LinkId      = link.Id,
                    link.ServiceId,
                    link.ApiAuditId,
                    svc.ServiceName,
                    svc.ServiceType,
                    svc.ApiHostId
                }).ToListAsync();

            return Results.Ok(rows);
        })
        .WithName("GetServicesForEndpoint")
        .WithOpenApi();

        // ---- CREATE: link one endpoint to one service (used by a drag-drop) ----
        group.MapPost("/", async (ApiServiceEndpoint input) =>
        {
            using var context = new EnterpriseContext();

            var svc = await context.ApiServices.FirstOrDefaultAsync(s => s.Id == input.ServiceId);
            if (svc is null)
                return Results.NotFound($"Service {input.ServiceId} not found.");

            var ep = await context.Apiaudit.FirstOrDefaultAsync(e => e.Id == input.ApiAuditId);
            if (ep is null)
                return Results.NotFound($"Endpoint {input.ApiAuditId} not found.");

            // Services only apply to endpoints on their own host.
            if (svc.ApiHostId.HasValue && ep.ApiHostId.HasValue && svc.ApiHostId != ep.ApiHostId)
                return Results.BadRequest(
                    $"Endpoint {ep.Id} is on host {ep.ApiHostId}, service {svc.Id} is on host {svc.ApiHostId}.");

            // Idempotent: don't duplicate an existing link.
            var existing = await context.ApiServiceEndpoints
                .FirstOrDefaultAsync(l => l.ServiceId == input.ServiceId && l.ApiAuditId == input.ApiAuditId);
            if (existing is not null)
                return Results.Ok(existing);

            var link = new ApiServiceEndpoint
            {
                ServiceId   = input.ServiceId,
                ApiAuditId  = input.ApiAuditId,
                ApiHostId   = svc.ApiHostId,
                CreatedDate = DateTime.UtcNow
            };

            context.ApiServiceEndpoints.Add(link);
            await context.SaveChangesAsync();

            return Results.Created($"/api/apiserviceendpoints/{link.Id}", link);
        })
        .WithName("CreateServiceEndpointLink")
        .WithOpenApi();

        // ---- SET: replace all endpoints for a service in one call (bulk save) ----
        group.MapPost("/service/{serviceId:int}/set", async (int serviceId, List<int> apiAuditIds) =>
        {
            using var context = new EnterpriseContext();

            var svc = await context.ApiServices.FirstOrDefaultAsync(s => s.Id == serviceId);
            if (svc is null)
                return Results.NotFound($"Service {serviceId} not found.");

            var ids = (apiAuditIds ?? new List<int>()).Distinct().ToList();

            // Reject any endpoint not on the service's host.
            if (svc.ApiHostId.HasValue && ids.Count > 0)
            {
                var offHost = await context.Apiaudit
                    .Where(e => ids.Contains(e.Id) && e.ApiHostId != svc.ApiHostId)
                    .Select(e => e.Id)
                    .ToListAsync();
                if (offHost.Any())
                    return Results.BadRequest(
                        $"Endpoints not on service host {svc.ApiHostId}: {string.Join(", ", offHost)}");
            }

            var current = await context.ApiServiceEndpoints
                .Where(l => l.ServiceId == serviceId)
                .ToListAsync();

            var toRemove = current.Where(l => !ids.Contains(l.ApiAuditId)).ToList();
            context.ApiServiceEndpoints.RemoveRange(toRemove);

            var have = current.Select(l => l.ApiAuditId).ToHashSet();
            foreach (var aid in ids.Where(a => !have.Contains(a)))
            {
                context.ApiServiceEndpoints.Add(new ApiServiceEndpoint
                {
                    ServiceId   = serviceId,
                    ApiAuditId  = aid,
                    ApiHostId   = svc.ApiHostId,
                    CreatedDate = DateTime.UtcNow
                });
            }

            await context.SaveChangesAsync();
            return Results.Ok(new { serviceId, linked = ids, removed = toRemove.Select(l => l.ApiAuditId) });
        })
        .WithName("SetServiceEndpoints")
        .WithOpenApi();

        // ---- DELETE: by link id ----
        group.MapDelete("/{id:int}", async (int id) =>
        {
            using var context = new EnterpriseContext();

            var link = await context.ApiServiceEndpoints.FirstOrDefaultAsync(l => l.Id == id);
            if (link is null)
                return Results.NotFound();

            context.ApiServiceEndpoints.Remove(link);
            await context.SaveChangesAsync();
            return Results.Ok();
        })
        .WithName("DeleteServiceEndpointLink")
        .WithOpenApi();

        // ---- DELETE: by (serviceId, apiAuditId) pair (handy for chip removal) ----
        group.MapDelete("/pair", async (int serviceId, int apiAuditId) =>
        {
            using var context = new EnterpriseContext();

            var link = await context.ApiServiceEndpoints
                .FirstOrDefaultAsync(l => l.ServiceId == serviceId && l.ApiAuditId == apiAuditId);
            if (link is null)
                return Results.NotFound();

            context.ApiServiceEndpoints.Remove(link);
            await context.SaveChangesAsync();
            return Results.Ok();
        })
        .WithName("DeleteServiceEndpointPair")
        .WithOpenApi();
    }
}
