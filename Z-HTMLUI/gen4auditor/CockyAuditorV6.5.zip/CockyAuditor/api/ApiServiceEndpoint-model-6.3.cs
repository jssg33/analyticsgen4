using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Enterprise.Models
{
    /// <summary>
    /// Join row linking one ApiService to one Apiaudit endpoint.
    /// Many-to-many: a service can attach to many endpoints, an endpoint to many services.
    /// ApiHostId is denormalized from the service so links can be filtered/validated by host
    /// without a second join. Services only attach to endpoints on the same host.
    /// </summary>
    [Table("ApiServiceEndpoints")]
    public partial class ApiServiceEndpoint
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int ServiceId { get; set; }    // -> ApiServices.Id
        public int ApiAuditId { get; set; }    // -> Apiaudit.Id  (the endpoint)

        public int? ApiHostId { get; set; }     // copied from the service at link time

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    }
}
