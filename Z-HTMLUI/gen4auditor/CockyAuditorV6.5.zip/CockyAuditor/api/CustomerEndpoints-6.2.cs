// Build 6.2: CustomerEndpoints. Changes from the version in use:
//  - GET / and GET /{id}: return each customer's Portfolios (id, userId, portfolioTargetInvestment, customerId).
//    Before, Portfolios was never loaded, so every customer showed 0 portfolios and the Customers page let you
//    delete a customer that still had portfolios. Projected, so there's no Portfolio -> Customer JSON cycle.
//  - PUT /{id}: also saves Tenantid and CreatedAt (it only copied FullName and UserId, answered 202, and dropped
//    the rest). CreatedAt is only changed when it differs by a minute or more, because the edit form works in
//    whole minutes. 400 for a missing body or blank UserId.
//  - POST /: CreatedAt defaults to now; returns the new customer with a real Location (/api/Customers/{id}).
//  - DELETE /{id}: 409 when the customer still has portfolios, instead of a database error (or a cascade delete).
// Assumes Enterprise.Models.Portfolio has Id, UserId, PortfolioTargetInvestment, CustomerId and that
// EnterpriseContext has a Portfolios DbSet (as in the Swagger sample).
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Enterprise.Models;

namespace somecontrollers.Controllers;

public static class CustomerEndpoints
{
    public static void MapCustomerEndpoints(this IEndpointRouteBuilder routes)
    {
        var group = routes.MapGroup("/api/Customers").WithTags(nameof(Customer));

        // GET ALL
        group.MapGet("/", async () =>
        {
            using var context = new EnterpriseContext();
            return await context.Customers.AsNoTracking()
                .Select(c => new
                {
                    c.Id, c.Tenantid, c.UserId, c.FullName, c.CreatedAt,
                    Portfolios = c.Portfolios.Select(p => new { p.Id, p.UserId, p.PortfolioTargetInvestment, p.CustomerId }).ToList()
                })
                .ToListAsync();
        })
        .WithName("GetAllCustomers")
        .WithOpenApi();

        // GET BY ID
        group.MapGet("/{id:int}", async (int id) =>
        {
            using var context = new EnterpriseContext();
            var list = await context.Customers.AsNoTracking()
                .Where(c => c.Id == id)
                .Select(c => new
                {
                    c.Id, c.Tenantid, c.UserId, c.FullName, c.CreatedAt,
                    Portfolios = c.Portfolios.Select(p => new { p.Id, p.UserId, p.PortfolioTargetInvestment, p.CustomerId }).ToList()
                })
                .ToListAsync();
            return Results.Ok(list);
        })
        .WithName("GetCustomerById")
        .WithOpenApi();

        // CREATE
        group.MapPost("/", async (Customer input) =>
        {
            if (string.IsNullOrWhiteSpace(input.UserId))
                return Results.BadRequest("UserId is required.");

            using var context = new EnterpriseContext();
            input.Id = 0;
            input.Portfolios = new List<Portfolio>();
            if (input.CreatedAt == default) input.CreatedAt = DateTime.UtcNow;

            context.Customers.Add(input);
            await context.SaveChangesAsync();
            return Results.Created($"/api/Customers/{input.Id}", new { input.Id, input.Tenantid, input.UserId, input.FullName, input.CreatedAt });
        })
        .WithName("CreateCustomer")
        .WithOpenApi();

        // UPDATE
        group.MapPut("/{id:int}", async (int id, Customer input) =>
        {
            if (input is null)
                return Results.BadRequest("No customer in the request body.");
            if (string.IsNullOrWhiteSpace(input.UserId))
                return Results.BadRequest("UserId is required.");

            using var context = new EnterpriseContext();
            var entity = await context.Customers.FirstOrDefaultAsync(c => c.Id == id);
            if (entity == null)
                return Results.NotFound("No Customer with ID:" + id);

            entity.FullName = input.FullName;
            entity.UserId = input.UserId;
            entity.Tenantid = input.Tenantid;
            if (input.CreatedAt != default && Math.Abs((input.CreatedAt - entity.CreatedAt).TotalMinutes) >= 1)
                entity.CreatedAt = input.CreatedAt;
            // Portfolios are never touched here

            await context.SaveChangesAsync();
            return Results.Accepted($"/api/Customers/{id}", $"Updated ID:{id}");
        })
        .WithName("UpdateCustomer")
        .WithOpenApi();

        // DELETE
        group.MapDelete("/{id:int}", async (int id) =>
        {
            using var context = new EnterpriseContext();
            var entity = await context.Customers.FirstOrDefaultAsync(c => c.Id == id);
            if (entity == null)
                return Results.NotFound("No Customer with ID:" + id);

            var portfolios = await context.Portfolios.CountAsync(p => p.CustomerId == id);
            if (portfolios > 0)
                return Results.Conflict($"Customer {id} has {portfolios} portfolio(s); remove them first.");

            context.Customers.Remove(entity);
            await context.SaveChangesAsync();
            return Results.Ok();
        })
        .WithName("DeleteCustomer")
        .WithOpenApi();
    }
}
