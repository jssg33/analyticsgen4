using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Enterprise.Models
{
    /// <summary>
    /// Per-host Enterprise(9) log setup (build 6.4). One row = one Enterprise(9) log a host exposes,
    /// with the exact route (EndpointUrl: a path joined to the host's URL, or a full absolute URL when a
    /// region's base differs). ApiHostId is nullable so the list route doesn't error on an unassigned row.
    /// </summary>
    [Table("Enterprise9")]
    public partial class Enterprise9
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int? ApiHostId { get; set; }        // -> ApiHost.Id
        public string? ApiHostName { get; set; }    // denormalized for display / filtering

        public string LogName { get; set; } = string.Empty;   // canonical set name, e.g. "Apilog"
        public string? LogDescription { get; set; }            // display label, e.g. "API Log"
        public string? EndpointUrl { get; set; }               // path or full URL
        public string? HttpMethod { get; set; }                // usually GET (the list route)

        public bool IsRequired { get; set; }        // this host is expected to expose this log
        public bool IsImplemented { get; set; }     // confirmed present
        public DateTime? LastValidated { get; set; }

        public string? Notes { get; set; }
        public bool IsActive { get; set; } = true;

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime? ModifiedDate { get; set; }
    }
}
